// supabase/functions/send-email/index.ts
// Deploy with: supabase functions deploy send-email
// Set secret: supabase secrets set RESEND_API_KEY=your_key

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
const FROM_EMAIL = Deno.env.get("FROM_EMAIL") || "noreply@morelife.app";
const FROM_NAME = Deno.env.get("FROM_NAME") || "More Life";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface EmailPayload {
  to: string;
  subject: string;
  html: string;
  type: string;
}

const emailTemplates: Record<string, (data: any) => { subject: string; html: string }> = {

  application_received: (data) => ({
    subject: "Your More Life Application Has Been Received",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life</h1>
          <p style="color: #AED6F1; margin: 4px 0 0 0;">Wellness Coordination Platform</p>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">Application Received</h2>
          <p>Hi ${data.name},</p>
          <p>Thank you for applying to join the More Life platform as a Wellness Instructor. We have received your application and it is currently under review.</p>
          <p>Our team will review your credentials and be in touch shortly. If you have any questions in the meantime, please don't hesitate to reach out.</p>
          <p style="margin-top: 32px; color: #666; font-size: 14px;">— The More Life Team<br>${data.admin_phone}</p>
        </div>
      </div>
    `,
  }),

  application_approved: (data) => ({
    subject: "Congratulations — Your More Life Application Has Been Approved",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1E8449;">✓ Application Approved</h2>
          <p>Hi ${data.name},</p>
          <p>We're excited to let you know that your application to join the More Life platform has been <strong>approved</strong>.</p>
          <p>You can now log in to your portal to complete your profile and set your availability.</p>
          <a href="${data.portal_url}" style="display: inline-block; background: #1A5276; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; margin-top: 16px;">Access Your Portal</a>
          <p style="margin-top: 32px; color: #666; font-size: 14px;">— The More Life Team<br>${data.admin_phone}</p>
        </div>
      </div>
    `,
  }),

  application_rejected: (data) => ({
    subject: "Update on Your More Life Application",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">Application Update</h2>
          <p>Hi ${data.name},</p>
          <p>Thank you for your interest in joining the More Life platform. After careful review, we are unable to move forward with your application at this time.</p>
          <p>If you have questions or believe this decision was made in error, please contact us directly.</p>
          <p style="margin-top: 32px; color: #666; font-size: 14px;">— The More Life Team<br>${data.admin_phone}</p>
        </div>
      </div>
    `,
  }),

  new_application_admin: (data) => ({
    subject: `New Wellness Instructor Application — ${data.instructor_name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life Admin</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">New Application Received</h2>
          <p>A new Wellness Instructor application has been submitted and is waiting in your approval queue.</p>
          <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
            <tr><td style="padding: 8px; color: #666;">Name:</td><td style="padding: 8px; font-weight: bold;">${data.instructor_name}</td></tr>
            <tr style="background: #eee;"><td style="padding: 8px; color: #666;">Email:</td><td style="padding: 8px;">${data.instructor_email}</td></tr>
            <tr><td style="padding: 8px; color: #666;">Services:</td><td style="padding: 8px;">${data.services}</td></tr>
          </table>
          <a href="${data.admin_url}" style="display: inline-block; background: #1A5276; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; margin-top: 8px;">Review Application</a>
        </div>
      </div>
    `,
  }),

  new_facility_inquiry_admin: (data) => ({
    subject: `New Facility Inquiry — ${data.facility_name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life Admin</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">New Facility Inquiry</h2>
          <p>A new facility has submitted an inquiry.</p>
          <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
            <tr><td style="padding: 8px; color: #666;">Facility:</td><td style="padding: 8px; font-weight: bold;">${data.facility_name}</td></tr>
            <tr style="background: #eee;"><td style="padding: 8px; color: #666;">Type:</td><td style="padding: 8px;">${data.facility_type}</td></tr>
            <tr><td style="padding: 8px; color: #666;">Director:</td><td style="padding: 8px;">${data.director_name}</td></tr>
            <tr style="background: #eee;"><td style="padding: 8px; color: #666;">Services Desired:</td><td style="padding: 8px;">${data.services_desired}</td></tr>
          </table>
          <a href="${data.admin_url}" style="display: inline-block; background: #1A5276; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; margin-top: 8px;">View Inquiry</a>
        </div>
      </div>
    `,
  }),

  availability_updated_admin: (data) => ({
    subject: `Availability Updated — ${data.instructor_name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life Admin</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #E67E22;">⚠ Availability Update</h2>
          <p><strong>${data.instructor_name}</strong> has updated their availability on the platform.</p>
          <p style="background: #FEF9E7; padding: 12px; border-left: 4px solid #F39C12; border-radius: 4px;">
            <strong>Reminder:</strong> The instructor has been instructed to also call you directly at ${data.admin_phone} to confirm schedule changes.
          </p>
          <a href="${data.admin_url}" style="display: inline-block; background: #1A5276; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; margin-top: 16px;">View Instructor Profile</a>
        </div>
      </div>
    `,
  }),

  contract_sent: (data) => ({
    subject: `Contract Sent for Signature — ${data.party_name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life Admin</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">Contract Sent</h2>
          <p>A <strong>${data.contract_type}</strong> contract has been sent to <strong>${data.party_name}</strong> for signature.</p>
          <a href="${data.admin_url}" style="display: inline-block; background: #1A5276; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; margin-top: 8px;">View Contract</a>
        </div>
      </div>
    `,
  }),

  contract_signed: (data) => ({
    subject: `Contract Signed — ${data.party_name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life Admin</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1E8449;">✓ Contract Signed</h2>
          <p><strong>${data.party_name}</strong> has signed their ${data.contract_type} contract.</p>
          <a href="${data.admin_url}" style="display: inline-block; background: #1A5276; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; margin-top: 8px;">View Signed Contract</a>
        </div>
      </div>
    `,
  }),

  credential_expiring: (data) => ({
    subject: `Action Required — ${data.credential_type} Expiring in ${data.days_left} Days`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #E67E22;">⚠ ${data.credential_type} Expiring Soon</h2>
          <p>Hi ${data.name},</p>
          <p>Your <strong>${data.credential_name}</strong> is expiring in <strong>${data.days_left} days</strong> (on ${data.expiry_date}).</p>
          <p>Please contact us as soon as possible to provide your renewed certificate and maintain your active status on the platform.</p>
          <p style="margin-top: 32px; color: #666; font-size: 14px;">— The More Life Team<br>${data.admin_phone}</p>
        </div>
      </div>
    `,
  }),

  // Admin copy of credential expiry alert
  credential_expiring_admin: (data) => ({
    subject: `⚠ Credential Expiring — ${data.instructor_name} (${data.days_left} days)`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life Admin</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #E67E22;">⚠ Credential Expiring</h2>
          <p>A credential for one of your active instructors is expiring soon.</p>
          <table style="width:100%; border-collapse:collapse; margin:16px 0;">
            <tr><td style="padding:8px;color:#666;">Instructor:</td><td style="padding:8px;font-weight:bold;">${data.instructor_name}</td></tr>
            <tr style="background:#eee;"><td style="padding:8px;color:#666;">Credential:</td><td style="padding:8px;">${data.credential_name}</td></tr>
            <tr><td style="padding:8px;color:#666;">Type:</td><td style="padding:8px;">${data.credential_type}</td></tr>
            <tr style="background:#eee;"><td style="padding:8px;color:#666;">Expires:</td><td style="padding:8px;font-weight:bold;color:#C0392B;">${data.expiry_date} (${data.days_left} days)</td></tr>
          </table>
          <p>The instructor has also been notified. Please follow up to ensure they renew on time.</p>
          <a href="${data.admin_url}" style="display:inline-block;background:#1A5276;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;margin-top:8px;">View Instructor Profile</a>
        </div>
      </div>
    `,
  }),

  // Session reminder — sent to instructor and facility
  session_reminder: (data) => ({
    subject: `Session Reminder — ${data.session_date} at ${data.facility_name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">📅 Session Reminder</h2>
          <p>Hi ${data.name},</p>
          <p>This is a friendly reminder that you have a wellness session scheduled:</p>
          <table style="width:100%; border-collapse:collapse; margin:16px 0; background:white; border-radius:6px; overflow:hidden; border:1px solid #eee;">
            <tr style="background:#EBF5FB;"><td style="padding:10px 14px;color:#1A5276;font-weight:bold;">Date</td><td style="padding:10px 14px;">${data.session_date}</td></tr>
            <tr><td style="padding:10px 14px;color:#666;">Time</td><td style="padding:10px 14px;">${data.session_time}</td></tr>
            <tr style="background:#EBF5FB;"><td style="padding:10px 14px;color:#666;">Location</td><td style="padding:10px 14px;">${data.facility_name}</td></tr>
            ${data.facility_address ? `<tr><td style="padding:10px 14px;color:#666;">Address</td><td style="padding:10px 14px;">${data.facility_address}</td></tr>` : ''}
          </table>
          <p>If you need to cancel or reschedule, contact us as soon as possible at <strong>${data.admin_phone}</strong>.</p>
          <p style="margin-top:32px;color:#666;font-size:14px;">— The More Life Team</p>
        </div>
      </div>
    `,
  }),

  // Payment due reminder — sent to facility
  payment_reminder_facility: (data) => ({
    subject: `Payment Due in ${data.days_until_due} Days — More Life`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">💳 Upcoming Payment Reminder</h2>
          <p>Hi ${data.director_name},</p>
          <p>This is a reminder that your upcoming wellness services payment is due soon.</p>
          <table style="width:100%; border-collapse:collapse; margin:16px 0; background:white; border-radius:6px; overflow:hidden; border:1px solid #eee;">
            <tr style="background:#EBF5FB;"><td style="padding:10px 14px;color:#1A5276;font-weight:bold;">Facility</td><td style="padding:10px 14px;">${data.facility_name}</td></tr>
            <tr><td style="padding:10px 14px;color:#666;">Amount Due</td><td style="padding:10px 14px;font-weight:bold;">$${data.amount}</td></tr>
            <tr style="background:#EBF5FB;"><td style="padding:10px 14px;color:#666;">Due Date</td><td style="padding:10px 14px;font-weight:bold;">${data.due_date}</td></tr>
          </table>
          <p>Payment will be collected via ACH from your account on file. If you have any questions or need to discuss the amount, please contact us.</p>
          <p style="margin-top:32px;color:#666;font-size:14px;">— The More Life Team<br>${data.admin_phone}</p>
        </div>
      </div>
    `,
  }),

  // Payment reminder — admin copy
  payment_reminder_admin: (data) => ({
    subject: `Payment Due Soon — ${data.facility_name} ($${data.amount} on ${data.due_date})`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #222;">
        <div style="background: #1A5276; padding: 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">More Life Admin</h1>
        </div>
        <div style="background: #f9f9f9; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #eee;">
          <h2 style="color: #1A5276;">💳 Facility Payment Due Soon</h2>
          <p>A facility payment is coming up. The facility has also been notified.</p>
          <table style="width:100%; border-collapse:collapse; margin:16px 0;">
            <tr><td style="padding:8px;color:#666;">Facility:</td><td style="padding:8px;font-weight:bold;">${data.facility_name}</td></tr>
            <tr style="background:#eee;"><td style="padding:8px;color:#666;">Director:</td><td style="padding:8px;">${data.director_name}</td></tr>
            <tr><td style="padding:8px;color:#666;">Amount:</td><td style="padding:8px;font-weight:bold;">$${data.amount}</td></tr>
            <tr style="background:#eee;"><td style="padding:8px;color:#666;">Due Date:</td><td style="padding:8px;">${data.due_date}</td></tr>
          </table>
          <a href="${data.admin_url}" style="display:inline-block;background:#1A5276;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;margin-top:8px;">View Facility</a>
        </div>
      </div>
    `,
  }),

};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { type, to, data } = await req.json();

    if (!emailTemplates[type]) {
      return new Response(JSON.stringify({ error: `Unknown email type: ${type}` }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const template = emailTemplates[type](data);

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: `${FROM_NAME} <${FROM_EMAIL}>`,
        to: [to],
        subject: template.subject,
        html: template.html,
      }),
    });

    const result = await response.json();

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
