// js/app.js
// ============================================================
// MORE LIFE — SHARED APP UTILITIES
// Loaded on every page
// ============================================================

// ─── SUPABASE CLIENT ─────────────────────────────────────────
const { createClient } = supabase;
const sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ─── AUTH HELPERS ─────────────────────────────────────────────
const Auth = {
  async getSession() {
    const { data: { session } } = await sb.auth.getSession();
    return session;
  },

  async getUser() {
    const { data: { user } } = await sb.auth.getUser();
    return user;
  },

  async getRole() {
    const user = await this.getUser();
    if (!user) return null;
    const { data } = await sb.from('profiles').select('role').eq('id', user.id).single();
    return data?.role || null;
  },

  async requireAuth(allowedRoles = []) {
    const session = await this.getSession();
    if (!session) {
      window.location.href = rootPath('index.html');
      return null;
    }
    if (allowedRoles.length > 0) {
      const role = await this.getRole();
      if (!allowedRoles.includes(role)) {
        await this.redirectByRole(role);
        return null;
      }
    }
    return session;
  },

  async redirectByRole(role) {
    const paths = {
      admin: rootPath('admin/dashboard.html'),
      instructor: rootPath('instructor/portal.html'),
      facility: rootPath('facility/portal.html'),
    };
    window.location.href = paths[role] || rootPath('index.html');
  },

  async signOut() {
    await sb.auth.signOut();
    window.location.href = rootPath('index.html');
  },

  async signIn(email, password) {
    return await sb.auth.signInWithPassword({ email, password });
  },

  async signUp(email, password) {
    return await sb.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${SITE_URL}/index.html` }
    });
  }
};

// ─── SETTINGS HELPERS ─────────────────────────────────────────
const Settings = {
  _cache: null,

  async getAll() {
    if (this._cache) return this._cache;
    const { data } = await sb.from('site_settings').select('key, value');
    this._cache = {};
    (data || []).forEach(s => this._cache[s.key] = s.value);
    return this._cache;
  },

  async get(key) {
    const all = await this.getAll();
    return all[key] || '';
  },

  async set(key, value) {
    this._cache = null;
    return await sb.from('site_settings').upsert({ key, value, updated_at: new Date().toISOString() });
  }
};

// ─── EMAIL HELPERS ─────────────────────────────────────────────
const Email = {
  async send(type, to, data) {
    try {
      const { data: result, error } = await sb.functions.invoke('send-email', {
        body: { type, to, data }
      });
      if (error) console.error('Email error:', error);
      return result;
    } catch (e) {
      console.error('Email send failed:', e);
    }
  }
};

// ─── TOAST NOTIFICATIONS ──────────────────────────────────────
const Toast = {
  container: null,

  init() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toast-container';
      document.body.appendChild(this.container);
    }
  },

  show(message, type = 'default', duration = 3500) {
    this.init();
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    this.container.appendChild(toast);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => toast.classList.add('show'));
    });
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },

  success(msg) { this.show(msg, 'success'); },
  error(msg) { this.show(msg, 'error', 5000); },
  warning(msg) { this.show(msg, 'warning'); },
};

// ─── MODAL HELPERS ────────────────────────────────────────────
const Modal = {
  open(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('open');
  },

  close(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('open');
  },

  confirm(message) {
    return new Promise(resolve => {
      const existing = document.getElementById('confirm-modal');
      if (existing) existing.remove();

      const modal = document.createElement('div');
      modal.id = 'confirm-modal';
      modal.className = 'modal-overlay open';
      modal.innerHTML = `
        <div class="modal" style="max-width: 400px;">
          <div class="modal-header">
            <h3>Confirm</h3>
          </div>
          <div class="modal-body">
            <p>${message}</p>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost btn-sm" id="confirm-no">Cancel</button>
            <button class="btn btn-danger btn-sm" id="confirm-yes">Confirm</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
      document.getElementById('confirm-yes').onclick = () => { modal.remove(); resolve(true); };
      document.getElementById('confirm-no').onclick = () => { modal.remove(); resolve(false); };
    });
  }
};

// ─── TABS ─────────────────────────────────────────────────────
function initTabs(containerSelector) {
  const containers = document.querySelectorAll(containerSelector || '.tabs');
  containers.forEach(tabBar => {
    tabBar.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.tab;
        tabBar.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const panels = tabBar.closest('.card') || tabBar.parentElement.parentElement;
        panels.querySelectorAll('.tab-panel').forEach(p => {
          p.classList.toggle('active', p.dataset.tab === target);
        });
      });
    });
  });
}

// ─── MOBILE SIDEBAR ───────────────────────────────────────────
function initMobileSidebar() {
  const hamburger = document.querySelector('.hamburger');
  const sidebar = document.querySelector('.sidebar');
  if (hamburger && sidebar) {
    hamburger.addEventListener('click', () => sidebar.classList.toggle('open'));
    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('open') && !sidebar.contains(e.target) && e.target !== hamburger) {
        sidebar.classList.remove('open');
      }
    });
  }
}

// ─── ROOT PATH HELPER ─────────────────────────────────────────
// Generates correct path regardless of subdirectory depth
function rootPath(path) {
  const depth = (window.location.pathname.match(/\//g) || []).length - 1;
  const prefix = depth > 1 ? '../'.repeat(depth - 1) : '';
  return prefix + path;
}

// ─── CURRENT USER DISPLAY ─────────────────────────────────────
async function populateUserInfo() {
  const el = document.getElementById('user-info');
  if (!el) return;
  const user = await Auth.getUser();
  if (user) el.textContent = user.email;
}

// ─── DATE FORMATTING ──────────────────────────────────────────
function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const diff = new Date(dateStr) - new Date();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

// ─── DYNAMIC LIST BUILDER ─────────────────────────────────────
// Used for social media fields, services, etc.
function DynamicList(containerId, renderItemFn, emptyLabel = 'Add item') {
  const container = document.getElementById(containerId);
  if (!container) return null;

  const list = container.querySelector('ul') || (() => {
    const ul = document.createElement('ul');
    ul.className = 'dynamic-list';
    container.insertBefore(ul, container.querySelector('.btn-add-item'));
    return ul;
  })();

  function addItem(data = {}) {
    const li = document.createElement('li');
    li.className = 'dynamic-list-item';
    li.innerHTML = renderItemFn(data);
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'btn-remove-item';
    removeBtn.innerHTML = '×';
    removeBtn.onclick = () => li.remove();
    li.appendChild(removeBtn);
    list.appendChild(li);
    return li;
  }

  function getValues(selector) {
    return Array.from(list.querySelectorAll(selector))
      .map(el => el.value.trim())
      .filter(Boolean);
  }

  function getItems(rowSelector, fieldSelectors) {
    return Array.from(list.querySelectorAll(rowSelector)).map(item => {
      const result = {};
      fieldSelectors.forEach(f => {
        result[f] = item.querySelector(`[name="${f}"]`)?.value?.trim() || '';
      });
      return result;
    }).filter(item => Object.values(item).some(Boolean));
  }

  return { addItem, getValues, getItems, list };
}

// ─── CREDENTIAL STATUS BADGE ──────────────────────────────────
function credentialBadge(expiryDate) {
  if (!expiryDate) return '<span class="badge badge-pending">No date</span>';
  const days = daysUntil(expiryDate);
  if (days < 0) return '<span class="badge badge-expired">Expired</span>';
  if (days <= 30) return `<span class="badge badge-expiring">Expiring in ${days}d</span>`;
  if (days <= 60) return `<span class="badge badge-expiring">Expiring in ${days}d</span>`;
  return `<span class="badge badge-approved">Valid · ${formatDate(expiryDate)}</span>`;
}

// ─── INIT ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initMobileSidebar();
  initTabs();
  populateUserInfo();

  // Sign out buttons
  document.querySelectorAll('.sign-out-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      Auth.signOut();
    });
  });

  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });

  // Close modal buttons
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.modal-overlay').classList.remove('open');
    });
  });
});
