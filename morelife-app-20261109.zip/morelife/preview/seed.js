// preview/seed.js
// ============================================================
// MORE LIFE — LOCAL PREVIEW SEED DATA
// Populates the in-memory SQLite DB so every portal has realistic
// content to click through. Mirrors the defaults from migrations
// 001/002/003 plus a few demo instructors, facilities, and matches.
// ============================================================

// ISO-date helper: today + N days (N can be negative)
function daysFromNow(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10); // YYYY-MM-DD
}
const NOW = new Date().toISOString();

// Demo login accounts (documented on the preview landing page)
const DEMO_PASSWORD = 'demo1234';
const USERS = {
  admin:      { id: 'demo-admin',   email: 'admin@morelife.test',   role: 'admin' },
  instructor: { id: 'demo-grace',   email: 'grace@morelife.test',   role: 'instructor' },
  facility:   { id: 'demo-sunrise', email: 'sunrise@morelife.test', role: 'facility' },
};

// Generic insert helper
function insert(db, table, row) {
  const cols = Object.keys(row);
  const sql = `INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`;
  db.prepare(sql).run(...cols.map(c => row[c]));
}

const FACILITY_TEMPLATE = `# FACILITY SERVICES AGREEMENT

**More Life Wellness Coordination Platform**
*DRAFT — Subject to Attorney Review*

---

## 1. Parties

This Facility Services Agreement (the "Agreement") is entered into as of **{{contract_start_date}}**, by and between:

**Service Provider:** {{business_name}}, a {{business_entity_type}}, located at {{business_address}} (hereinafter "More Life" or "the Company").

**Facility:** {{facility_name}}, a {{facility_type}}, located at {{facility_address}} (hereinafter "Facility"). The authorized representative is {{director_name}}, {{director_title}}.

---

## 2. Purpose & Scope of Services

More Life agrees to coordinate and facilitate the delivery of group wellness sessions to the Facility's adult and senior participants. Services include: {{services_authorized}}.

All sessions will be conducted on-site at the Facility by a vetted Wellness Instructor arranged by More Life. Sessions are group format and one (1) hour in duration.

---

## 3. Session Schedule

Sessions will be conducted **{{sessions_per_week}}** time(s) per week on agreed days and times to be confirmed upon scheduling.

---

## 4. Fees & Payment Terms

The Facility agrees to pay More Life a monthly service fee of **{{monthly_fee}}** (USD), due in advance on the **{{payment_due_date}}** of each month.

**Credit/Refund Policy:** {{credit_refund_policy}}

---

## 5. Term & Termination

This Agreement commences on {{contract_start_date}} for an initial term of {{contract_duration}}, renewing automatically for {{renewal_period}} terms unless either party provides {{termination_notice_days}} days written notice.

---

## 6. Governing Law

This Agreement shall be governed by the laws of the State of {{governing_state}}.

---

## 7. Signatures

**More Life:** {{signatory_name}} | Title: {{signatory_title}} | Date: ___________

**Facility:** {{director_name}} | Title: {{director_title}} | Date: ___________
`;

const INSTRUCTOR_TEMPLATE = `# WELLNESS INSTRUCTOR AGREEMENT

**More Life Wellness Coordination Platform**
*DRAFT — Subject to Attorney Review*

---

## 1. Parties

This Wellness Instructor Agreement (the "Agreement") is entered into as of **{{contract_start_date}}**, by and between **{{business_name}}** ("More Life") and **{{instructor_legal_name}}**, an independent contractor ("Instructor").

---

## 2. Authorized Services

The Instructor is authorized to deliver: **{{services_authorized}}**. Teletraining authorized: **{{teletraining_authorized}}**. All sessions are in-person at the assigned facility, group format, one (1) hour duration.

---

## 3. Compensation

**Rate:** {{pay_rate}}. **Pay Schedule:** {{pay_schedule}} (default: biweekly). The Instructor is solely responsible for all taxes; More Life issues Form 1099 as required.

---

## 4. Credentials & Insurance

The Instructor maintains valid certifications (**{{certifications}}**) and professional liability insurance (minimum {{insurance_minimum}}). Prior to conducting sessions at any facility, the Instructor agrees to add that facility as an Additional Insured and Certificate Holder on their policy.

---

## 5. Non-Solicitation

During this Agreement and for {{non_solicitation_period}} following termination, the Instructor agrees not to directly solicit facilities introduced through More Life.

---

## 6. Governing Law

This Agreement shall be governed by the laws of the State of {{governing_state}}.

---

## 7. Signatures

**More Life:** {{signatory_name}} | Title: {{signatory_title}} | Date: ___________

**Wellness Instructor:** {{instructor_legal_name}} | Date: ___________
`;

function seed(db) {
  // ─── auth users + profiles ─────────────────────────────────
  for (const u of Object.values(USERS)) {
    insert(db, 'auth_users', { id: u.id, email: u.email, password: DEMO_PASSWORD, created_at: NOW });
    insert(db, 'profiles', { id: u.id, role: u.role, created_at: NOW });
  }

  // ─── site settings (001 defaults + 003 updates/additions) ──
  const settings = {
    business_name: 'More Life',
    business_address: '1200 Brickell Ave, Suite 400, Miami, FL 33131',
    business_entity_type: 'LLC',
    admin_phone: '1-786-346-6722',
    admin_email: 'admin@morelife.test',
    contract_signatory_name: 'Jordan Alvarez',
    contract_signatory_title: 'Managing Member',
    logo_url: '',
    expiry_warning_days_first: '30',   // 003 updated
    expiry_warning_days_second: '7',   // 003 updated
    availability_notice_text: 'You must also call us at {phone} to notify us directly of any schedule changes. Platform updates alone are not sufficient.',
    credit_refund_policy: 'In the event that a scheduled Wellness Instructor is unable to fulfill a session for any reason, the Facility will receive a credit toward a future invoice, or a pro-rated refund for that session.',
    cancellation_policy: 'We ask that you provide 48 hours notice when possible so we may notify the facility in a timely manner.',
    session_reminder_hours: '24',
    payment_reminder_days: '5',
    fall_risk_reminder_months: '6',
    governing_state: 'Florida',
    default_notice_days: '30',
    docusign_api_key: '',
    payment_processor: '',
    payment_processor_key: '',
    instructor_pay_cycle: 'biweekly',
  };
  for (const [key, value] of Object.entries(settings)) {
    insert(db, 'site_settings', { key, value, updated_at: NOW });
  }

  // ─── service categories (002 defaults) ─────────────────────
  const cats = ['Chair Yoga','Balance Training','Strength Training','Coordination','Pilates','Fitness','Tai Chi','Stretching & Flexibility','Breathing & Relaxation','Neurosize','Other'];
  cats.forEach((name, i) => insert(db, 'service_categories', {
    id: `cat-${i + 1}`, name, sort_order: i + 1, active: 1, created_at: NOW, updated_at: NOW,
  }));

  // ─── contract templates (001) ──────────────────────────────
  insert(db, 'contract_templates', { id: 'tpl-facility', template_type: 'facility', content: FACILITY_TEMPLATE, updated_at: NOW, updated_by: USERS.admin.id });
  insert(db, 'contract_templates', { id: 'tpl-instructor', template_type: 'instructor', content: INSTRUCTOR_TEMPLATE, updated_at: NOW, updated_by: USERS.admin.id });

  // ─── instructors ───────────────────────────────────────────
  insert(db, 'wellness_instructors', {
    id: 'i-grace', user_id: USERS.instructor.id, legal_name: 'Grace Nguyen', nickname: 'Grace',
    business_name: 'Grace Moves Wellness', phone: '305-555-0142', email: 'grace@morelife.test',
    address: '88 Coral Way, Miami, FL', headshot_url: '', bio: 'Certified chair-yoga and balance instructor with a decade of experience leading gentle group sessions for seniors. Warm, patient, and focused on fall prevention.',
    years_experience: 10, teletraining: 1, drive_minutes: 40, space_requirements: 'Open room for 12, chairs provided by facility.',
    service_area_lat: 25.7617, service_area_lng: -80.1918, service_area_radius_km: 30,
    status: 'approved', admin_notes: 'Excellent references. Fast to respond.', created_at: daysFromNow(-120) + 'T12:00:00Z', updated_at: NOW,
  });
  insert(db, 'wellness_instructors', {
    id: 'i-marcus', user_id: null, legal_name: 'Marcus Bell', nickname: 'Marcus',
    business_name: '', phone: '786-555-0199', email: 'marcus@example.com',
    address: 'Hialeah, FL', headshot_url: '', bio: 'Strength and coordination coach specializing in adult day programs. Background in physical therapy assistance.',
    years_experience: 6, teletraining: 0, drive_minutes: 25, space_requirements: 'Space for light resistance equipment.',
    service_area_lat: 25.86, service_area_lng: -80.27, service_area_radius_km: 20,
    status: 'approved', admin_notes: '', created_at: daysFromNow(-80) + 'T12:00:00Z', updated_at: NOW,
  });
  insert(db, 'wellness_instructors', {
    id: 'i-aisha', user_id: null, legal_name: 'Aisha Rahman', nickname: '',
    business_name: '', phone: '305-555-0170', email: 'aisha@example.com', address: 'Miami, FL',
    headshot_url: '', bio: 'Tai Chi and breathing/relaxation instructor. New applicant awaiting review.',
    years_experience: 4, teletraining: 1, drive_minutes: 35, space_requirements: 'Quiet room.',
    service_area_lat: 25.77, service_area_lng: -80.2, service_area_radius_km: 25,
    status: 'pending', admin_notes: '', created_at: daysFromNow(-2) + 'T09:00:00Z', updated_at: NOW,
  });
  insert(db, 'wellness_instructors', {
    id: 'i-tom', user_id: null, legal_name: 'Tom Rivera', nickname: '',
    business_name: '', phone: '954-555-0133', email: 'tom@example.com', address: 'Fort Lauderdale, FL',
    headshot_url: '', bio: 'Applied but outside service radius for current facilities.',
    years_experience: 2, teletraining: 0, drive_minutes: 15, space_requirements: '',
    service_area_lat: 26.12, service_area_lng: -80.14, service_area_radius_km: 10,
    status: 'rejected', admin_notes: 'Too far from current demand. Revisit later.', created_at: daysFromNow(-40) + 'T09:00:00Z', updated_at: NOW,
  });

  // instructor services
  const svc = [
    ['i-grace', 'Chair Yoga'], ['i-grace', 'Balance Training'], ['i-grace', 'Stretching & Flexibility'],
    ['i-marcus', 'Strength Training'], ['i-marcus', 'Coordination'],
    ['i-aisha', 'Tai Chi'], ['i-aisha', 'Breathing & Relaxation'],
  ];
  svc.forEach(([instructor_id, service_name], i) => insert(db, 'instructor_services', { id: `svc-${i + 1}`, instructor_id, service_name }));

  // instructor social media (admin-only)
  insert(db, 'instructor_social_media', { id: 'sm-1', instructor_id: 'i-grace', platform: 'Instagram', url: 'https://instagram.com/gracemoves' });
  insert(db, 'instructor_social_media', { id: 'sm-2', instructor_id: 'i-grace', platform: 'LinkedIn', url: 'https://linkedin.com/in/gracenguyen' });

  // instructor credentials (one expiring soon -> surfaces in dashboard RPC)
  insert(db, 'instructor_credentials', { id: 'cr-1', instructor_id: 'i-grace', credential_type: 'insurance', name: 'Professional Liability Insurance', issuing_body: 'Hiscox', number: 'HX-9910', expiry_date: daysFromNow(200), file_url: 'private-docs/grace-insurance.pdf', status: 'active', created_at: NOW });
  insert(db, 'instructor_credentials', { id: 'cr-2', instructor_id: 'i-grace', credential_type: 'certification', name: 'RYT-200 Yoga Certification', issuing_body: 'Yoga Alliance', number: 'YA-55012', expiry_date: daysFromNow(20), file_url: 'private-docs/grace-ryt.pdf', status: 'active', created_at: NOW });
  insert(db, 'instructor_credentials', { id: 'cr-3', instructor_id: 'i-marcus', credential_type: 'insurance', name: 'Professional Liability Insurance', issuing_body: 'Next Insurance', number: 'NI-2231', expiry_date: daysFromNow(140), file_url: 'private-docs/marcus-insurance.pdf', status: 'active', created_at: NOW });

  // instructor availability
  const avail = [
    ['i-grace', 'Monday', '10:00', '12:00'], ['i-grace', 'Wednesday', '10:00', '12:00'], ['i-grace', 'Friday', '09:00', '11:00'],
    ['i-marcus', 'Tuesday', '13:00', '15:00'], ['i-marcus', 'Thursday', '13:00', '15:00'],
  ];
  avail.forEach(([instructor_id, day_of_week, start_time, end_time], i) => insert(db, 'instructor_availability', { id: `av-${i + 1}`, instructor_id, day_of_week, start_time, end_time, updated_at: NOW }));

  // ─── facilities ────────────────────────────────────────────
  insert(db, 'facilities', {
    id: 'f-sunrise', user_id: USERS.facility.id, facility_name: 'Sunrise Senior Day Center', director_name: 'Patricia Gomez',
    phone: '305-555-0400', email: 'sunrise@morelife.test', address: '450 NW 7th St, Miami, FL 33136', facility_type: 'senior_daycare',
    services_desired: 'Chair Yoga, Balance Training', preferred_schedule: 'Tuesdays and Thursdays, 10am',
    medical_considerations: 'Several participants use walkers; limited standing balance.', budget_range: '$300-$500/mo',
    status: 'active', admin_notes: 'Signed up quickly. Pays on time.', last_fall_risk_date: daysFromNow(-150), fall_risk_notes: 'Last assessment completed in spring.', created_at: daysFromNow(-110) + 'T12:00:00Z', updated_at: NOW,
  });
  insert(db, 'facilities', {
    id: 'f-bayview', user_id: null, facility_name: 'Bayview Medical Clinic', director_name: 'Dr. Alan Weiss',
    phone: '305-555-0455', email: 'bayview@example.com', address: '900 Biscayne Blvd, Miami, FL', facility_type: 'medical_center',
    services_desired: 'Strength Training, Coordination', preferred_schedule: 'Thursday mornings',
    medical_considerations: '', budget_range: '$450-$600/mo', status: 'active', admin_notes: '', last_fall_risk_date: null, fall_risk_notes: null,
    created_at: daysFromNow(-70) + 'T12:00:00Z', updated_at: NOW,
  });
  insert(db, 'facilities', {
    id: 'f-oakwood', user_id: null, facility_name: 'Oakwood Adult Day Program', director_name: 'Renee Carter',
    phone: '954-555-0477', email: 'oakwood@example.com', address: 'Pembroke Pines, FL', facility_type: 'senior_daycare',
    services_desired: 'Tai Chi, Stretching & Flexibility', preferred_schedule: 'Flexible, weekday afternoons',
    medical_considerations: '', budget_range: '$250-$400/mo', status: 'active', admin_notes: 'New inquiry — needs a match.', last_fall_risk_date: null, fall_risk_notes: null,
    created_at: daysFromNow(-3) + 'T10:00:00Z', updated_at: NOW,
  });

  // ─── matches (admin-only rates; facility sees only shared profile) ──
  insert(db, 'matches', {
    id: 'm-1', instructor_id: 'i-grace', facility_id: 'f-sunrise',
    shared_fields: JSON.stringify({ name: true, headshot: true, bio: true, services: true, teletraining: true, certifications: true }),
    created_by: USERS.admin.id, created_at: daysFromNow(-100) + 'T12:00:00Z', facility_monthly_rate: 400, instructor_monthly_rate: 280,
  });
  insert(db, 'matches', {
    id: 'm-2', instructor_id: 'i-marcus', facility_id: 'f-bayview',
    shared_fields: JSON.stringify({ name: true, headshot: true, bio: true, services: true, teletraining: false, certifications: true }),
    created_by: USERS.admin.id, created_at: daysFromNow(-60) + 'T12:00:00Z', facility_monthly_rate: 500, instructor_monthly_rate: 320,
  });

  // ─── contracts ─────────────────────────────────────────────
  insert(db, 'contracts', {
    id: 'ct-1', contract_type: 'instructor', party_id: 'i-grace',
    content: INSTRUCTOR_TEMPLATE.replace('{{instructor_legal_name}}', 'Grace Nguyen').replace('{{pay_rate}}', '$280/month'),
    dynamic_fields: JSON.stringify({ pay_rate: '$280/month', pay_schedule: 'biweekly' }),
    status: 'signed', file_url: 'private-docs/grace-contract.pdf', sent_at: daysFromNow(-98) + 'T12:00:00Z', signed_at: daysFromNow(-95) + 'T12:00:00Z', created_by: USERS.admin.id, created_at: daysFromNow(-99) + 'T12:00:00Z',
  });
  insert(db, 'contracts', {
    id: 'ct-2', contract_type: 'facility', party_id: 'f-sunrise',
    content: FACILITY_TEMPLATE.replace('{{facility_name}}', 'Sunrise Senior Day Center').replace('{{monthly_fee}}', '$400'),
    dynamic_fields: JSON.stringify({ monthly_fee: '$400', sessions_per_week: '2' }),
    status: 'sent', file_url: null, sent_at: daysFromNow(-5) + 'T12:00:00Z', signed_at: null, created_by: USERS.admin.id, created_at: daysFromNow(-6) + 'T12:00:00Z',
  });
  insert(db, 'contracts', {
    id: 'ct-3', contract_type: 'instructor', party_id: 'i-marcus',
    content: INSTRUCTOR_TEMPLATE.replace('{{instructor_legal_name}}', 'Marcus Bell'),
    dynamic_fields: '{}', status: 'draft', file_url: null, sent_at: null, signed_at: null, created_by: USERS.admin.id, created_at: daysFromNow(-10) + 'T12:00:00Z',
  });

  // ─── compliance checklist rows for approved instructors ─────
  const items = ['insurance_on_file','certificate_holder_confirmed','certifications_verified','social_media_reviewed','contract_signed','ach_collected'];
  const graceChecked = new Set(['insurance_on_file','certifications_verified','social_media_reviewed','contract_signed']);
  items.forEach((item_key, i) => insert(db, 'instructor_compliance', {
    id: `cmp-g-${i}`, instructor_id: 'i-grace', item_key, checked: graceChecked.has(item_key) ? 1 : 0,
    checked_at: graceChecked.has(item_key) ? NOW : null, checked_by: graceChecked.has(item_key) ? USERS.admin.id : null, notes: null,
  }));
  items.forEach((item_key, i) => insert(db, 'instructor_compliance', {
    id: `cmp-m-${i}`, instructor_id: 'i-marcus', item_key, checked: item_key === 'insurance_on_file' ? 1 : 0,
    checked_at: item_key === 'insurance_on_file' ? NOW : null, checked_by: item_key === 'insurance_on_file' ? USERS.admin.id : null, notes: null,
  }));

  // ─── admin comments ────────────────────────────────────────
  insert(db, 'admin_comments', { id: 'ac-1', entity_type: 'instructor', entity_id: 'i-grace', comment: 'Confirmed insurance certificate holder language with Grace by phone.', created_by: USERS.admin.id, created_at: daysFromNow(-90) + 'T12:00:00Z' });
  insert(db, 'admin_comments', { id: 'ac-2', entity_type: 'facility', entity_id: 'f-sunrise', comment: 'Director prefers morning sessions. ACH set up.', created_by: USERS.admin.id, created_at: daysFromNow(-88) + 'T12:00:00Z' });
}

module.exports = { seed, USERS, DEMO_PASSWORD };
