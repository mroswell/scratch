// js/sidebar.js
// Renders the appropriate sidebar based on role
// Include this on every authenticated page

const Sidebar = {
  admin: `
    <aside class="sidebar">
      <div class="sidebar-logo">
        <h1 id="sidebar-business-name">More Life</h1>
        <span>Admin Panel</span>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section-label">Overview</div>
        <a href="dashboard.html" class="nav-link" data-page="dashboard">
          <i class="icon">⊞</i> Dashboard
        </a>
        <div class="nav-section-label">People</div>
        <a href="instructors.html" class="nav-link" data-page="instructors">
          <i class="icon">★</i> Wellness Instructors
        </a>
        <a href="facilities.html" class="nav-link" data-page="facilities">
          <i class="icon">⌂</i> Facilities
        </a>
        <div class="nav-section-label">Operations</div>
        <a href="matches.html" class="nav-link" data-page="matches">
          <i class="icon">⇄</i> Matches
        </a>
        <a href="contracts.html" class="nav-link" data-page="contracts">
          <i class="icon">✎</i> Contracts
        </a>
        <div class="nav-section-label">System</div>
        <a href="settings.html" class="nav-link" data-page="settings">
          <i class="icon">⚙</i> Settings
        </a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-info" id="user-info"></div>
        <a href="#" class="btn btn-ghost btn-sm w-full sign-out-btn">Sign Out</a>
      </div>
    </aside>
  `,

  instructor: `
    <aside class="sidebar">
      <div class="sidebar-logo">
        <h1 id="sidebar-business-name">More Life</h1>
        <span>Instructor Portal</span>
      </div>
      <nav class="sidebar-nav">
        <a href="portal.html" class="nav-link" data-page="portal">
          <i class="icon">⊞</i> My Portal
        </a>
        <a href="portal.html#profile" class="nav-link">
          <i class="icon">✎</i> My Profile
        </a>
        <a href="portal.html#availability" class="nav-link">
          <i class="icon">◷</i> Availability
        </a>
        <a href="portal.html#contract" class="nav-link">
          <i class="icon">✎</i> My Contract
        </a>
        <a href="portal.html#credentials" class="nav-link">
          <i class="icon">✓</i> Credentials
        </a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-info" id="user-info"></div>
        <a href="#" class="btn btn-ghost btn-sm w-full sign-out-btn">Sign Out</a>
      </div>
    </aside>
  `,

  facility: `
    <aside class="sidebar">
      <div class="sidebar-logo">
        <h1 id="sidebar-business-name">More Life</h1>
        <span>Facility Portal</span>
      </div>
      <nav class="sidebar-nav">
        <a href="portal.html" class="nav-link" data-page="portal">
          <i class="icon">⊞</i> My Portal
        </a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-info" id="user-info"></div>
        <a href="#" class="btn btn-ghost btn-sm w-full sign-out-btn">Sign Out</a>
      </div>
    </aside>
  `,

  async render(role) {
    const container = document.getElementById('sidebar-container');
    if (!container) return;
    container.innerHTML = this[role] || '';

    // Set active nav link
    const currentPage = window.location.pathname.split('/').pop().replace('.html','');
    container.querySelectorAll('.nav-link[data-page]').forEach(link => {
      if (link.dataset.page === currentPage) link.classList.add('active');
    });

    // Load business name from settings
    const businessName = await Settings.get('business_name');
    const nameEl = document.getElementById('sidebar-business-name');
    if (nameEl && businessName) nameEl.textContent = businessName;

    // Set document title
    document.title = `${businessName || 'More Life'} — ${document.title.split('—')[1]?.trim() || ''}`;

    // Re-init sidebar interactions
    initMobileSidebar();
    populateUserInfo();
  }
};
