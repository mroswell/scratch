// js/config.js
// ============================================================
// MORE LIFE — CONFIGURATION
// Replace the placeholder values below with your actual keys
// from your Supabase project settings > API
// ============================================================

const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
const SITE_URL = 'https://YOUR_GITHUB_USERNAME.github.io/morelife';
