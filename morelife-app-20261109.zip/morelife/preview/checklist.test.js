// preview/checklist.test.js — checklist parsing + update-proof persistence
const { test } = require('node:test');
const assert = require('node:assert');
const { stableId, parseMarkdown, applyState } = require('../checklist/checklist.js');

const SAMPLE = `# More Life — Task List

Intro paragraph that should be ignored.

## Phase 0 — Set up for testing

- [ ] Initialize git.
- [ ] Pin the Supabase JS CDN version.

## Phase 1 — Security

**1. Stop stored XSS**
- [ ] Add one shared escapeHtml helper.
- Done when: no script executes.

- [ ] Escape every user value.
`;

test('parseMarkdown extracts phases, tasks, subheads, and notes', () => {
  const s = parseMarkdown(SAMPLE);
  assert.equal(s.length, 2);
  assert.equal(s[0].title, 'Phase 0 — Set up for testing');
  const tasks0 = s[0].items.filter(i => i.type === 'task');
  assert.equal(tasks0.length, 2);
  const p1 = s[1];
  assert.ok(p1.items.some(i => i.type === 'subhead' && i.text.startsWith('1. Stop')));
  assert.ok(p1.items.some(i => i.type === 'note' && i.text.startsWith('Done when')));
  assert.equal(p1.items.filter(i => i.type === 'task').length, 2);
});

test('stableId is deterministic and text-sensitive', () => {
  assert.equal(stableId('Phase 1', 'Add helper'), stableId('Phase 1', 'Add helper'));
  assert.equal(stableId('Phase 1', 'Add  helper '), stableId('Phase 1', 'Add helper')); // whitespace-insensitive
  assert.notEqual(stableId('Phase 1', 'Add helper'), stableId('Phase 1', 'Add other'));
});

test('progress survives an app update: unchanged items keep their checked state', () => {
  // v1 of the checklist
  const v1 = parseMarkdown(SAMPLE);
  applyState(v1, {});
  // user checks the two Phase 0 tasks
  const saved = {};
  for (const it of v1[0].items.filter(i => i.type === 'task')) saved[it.id] = { done: true, ts: 1 };

  // v2 = the markdown was updated: a NEW task added to Phase 0, Phase 1 unchanged
  const updatedMd = SAMPLE.replace('- [ ] Pin the Supabase JS CDN version.',
    '- [ ] Pin the Supabase JS CDN version.\n- [ ] A brand-new task added later.');
  const v2 = parseMarkdown(updatedMd);
  const totals = applyState(v2, saved);

  const p0tasks = v2[0].items.filter(i => i.type === 'task');
  assert.equal(p0tasks.length, 3);
  // the two original tasks stay checked...
  assert.equal(p0tasks.find(t => t.text.startsWith('Initialize')).done, true);
  assert.equal(p0tasks.find(t => t.text.startsWith('Pin')).done, true);
  // ...the newly added one is unchecked
  assert.equal(p0tasks.find(t => t.text.startsWith('A brand-new')).done, false);
  assert.equal(totals.done, 2);
});

test('stale saved entries for removed items do not affect remaining items', () => {
  const v = parseMarkdown(SAMPLE);
  const saved = { 'deadbeef': { done: true, ts: 1 } }; // id that no longer exists
  const totals = applyState(v, saved);
  assert.equal(totals.done, 0); // nothing wrongly marked done
});
