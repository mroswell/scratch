-- ============================================================
-- MORE LIFE — MIGRATION 004
-- DocuSign fields, payment scheduling, cron infrastructure
-- Run AFTER 001, 002, 003
-- ============================================================

-- ── CONTRACTS: DocuSign tracking ─────────────────────────────
ALTER TABLE contracts
  ADD COLUMN IF NOT EXISTS docusign_envelope_id TEXT,
  ADD COLUMN IF NOT EXISTS signer_email          TEXT,
  ADD COLUMN IF NOT EXISTS signer_name           TEXT;

CREATE INDEX IF NOT EXISTS idx_contracts_envelope
  ON contracts (docusign_envelope_id)
  WHERE docusign_envelope_id IS NOT NULL;

-- ── FACILITIES: Payment scheduling ───────────────────────────
-- Day of month (1-28) the facility's ACH payment is due
ALTER TABLE facilities
  ADD COLUMN IF NOT EXISTS payment_due_day INTEGER
    CHECK (payment_due_day >= 1 AND payment_due_day <= 28);

-- ── NOTIFICATION LOG: Add entity tracking ────────────────────
-- Adds entity_id / entity_type so cron jobs can avoid re-sending
ALTER TABLE notification_log
  ADD COLUMN IF NOT EXISTS entity_type TEXT,
  ADD COLUMN IF NOT EXISTS entity_id   TEXT;

CREATE INDEX IF NOT EXISTS idx_notification_log_entity
  ON notification_log (entity_id, notification_type, created_at);

-- ── SITE SETTINGS: DocuSign ───────────────────────────────────
INSERT INTO site_settings (key, value) VALUES
  ('docusign_account_id',    ''),
  ('docusign_access_token',  ''),
  ('docusign_base_url',      'https://demo.docusign.net/restapi'),
  ('docusign_webhook_secret','')
ON CONFLICT (key) DO NOTHING;

-- ── pg_cron / pg_net EXTENSIONS ──────────────────────────────
-- These must be enabled in the Supabase dashboard under
-- Database → Extensions → pg_cron and pg_net
-- (They cannot be enabled via SQL in all Supabase tiers)

-- ── CRON JOB SETUP ───────────────────────────────────────────
-- Run these MANUALLY in the Supabase SQL editor after replacing
-- YOUR_PROJECT_REF and YOUR_SERVICE_ROLE_KEY with your actual values.
-- Find them in: Supabase Dashboard → Settings → API
--
-- Step 1: Set your project config as DB settings
--   ALTER DATABASE postgres SET app.supabase_url = 'https://YOUR_PROJECT_REF.supabase.co';
--   ALTER DATABASE postgres SET app.service_role_key = 'YOUR_SERVICE_ROLE_KEY';
--
-- Step 2: Create the daily cron schedule (8:00 AM UTC)
--   SELECT cron.schedule(
--     'more-life-daily-jobs',
--     '0 8 * * *',
--     $job$
--     SELECT net.http_post(
--       url         := current_setting('app.supabase_url') || '/functions/v1/run-daily-jobs',
--       headers     := jsonb_build_object(
--         'Content-Type',  'application/json',
--         'Authorization', 'Bearer ' || current_setting('app.service_role_key')
--       ),
--       body        := '{}'::jsonb
--     ) AS request_id;
--     $job$
--   );
--
-- To verify the schedule was created:
--   SELECT * FROM cron.job;
--
-- To remove it:
--   SELECT cron.unschedule('more-life-daily-jobs');
--
-- To run it manually right now (for testing):
--   SELECT net.http_post(
--     url     := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/run-daily-jobs',
--     headers := '{"Content-Type":"application/json","Authorization":"Bearer YOUR_SERVICE_ROLE_KEY"}'::jsonb,
--     body    := '{}'::jsonb
--   );
