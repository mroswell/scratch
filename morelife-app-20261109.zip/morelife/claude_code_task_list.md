# More Life — Claude Code Task List

Paste this into Claude Code with the project folder open. Put the v3 spec (MoreLife_AppSpec_v3.docx) alongside it, or summarize its business rules in CLAUDE.md.

## Ground rules for Claude Code

- This feedback was written from memory of the code, not from a fresh read. Before changing anything, read the relevant files and confirm each problem exists. If one doesn't, say so and skip it.
- The app is vanilla JS + Supabase + GitHub Pages. Do not introduce React or a build step.
- Eight months have passed. Check current Supabase, pg_cron/pg_net, DocuSign, and Resend documentation before relying on any API detail in the existing code.
- Make each task its own commit. Write a test first where a test is possible.

## Business rules the code must enforce (from the spec)

- Instructors and facilities never see each other's identity or contact details; Admin handles all coordination.
- Facilities see only the profile fields Admin chose to share for a match.
- Neither side ever sees the other's rate. The instructor pay rate is never visible to facilities, and the facility fee is never visible to instructors.
- Credential files are private to Admin.
- More Life never collects participant personal or health information.
- Fall risk assessments are performed and stored by the facility. More Life only logs a reminder date.
- Signed contracts are locked permanently.

---

## Phase 0 — Set up for testing

- [ ] Initialize git. Add .gitignore and a CLAUDE.md summarizing the stack and the rules above.
- [ ] Set up local Supabase (`supabase init`, `supabase start`) and apply migrations 001–004 to it. Fix any migration that fails on a clean database.
- [ ] Pin the Supabase JS CDN version in every HTML page (currently unpinned `@2`).

## Phase 1 — Security and privacy (do before any real data)

**1. Stop stored XSS**
- [ ] Add one shared `escapeHtml` helper in `js/app.js`.
- [ ] Escape every user-supplied value rendered via `innerHTML` across the admin, instructor, and facility pages (names, bios, comments, notes, addresses, URLs). Validate that social media and other URLs start with http(s).
- Done when: submitting `<img src=x onerror=alert(1)>` in every free-text field produces no script execution on any page.

**2. Remove secrets from `site_settings`**
- [ ] Delete the DocuSign and payment processor key fields from the Settings page and from `site_settings`.
- [ ] Keep all such secrets in Edge Function secrets only.
- [ ] Review the RLS policy on `site_settings` so only genuinely public values (business name, logo, admin phone) are readable without login.
- Done when: an anonymous API request to `site_settings` returns no credentials.

**3. Move privacy rules into the database**
- [ ] Check what a facility-role user can actually query through the API from `matches`, `wellness_instructors`, and related tables.
- [ ] Move `facility_monthly_rate` and `instructor_monthly_rate` into an admin-only table (for example `match_financials`).
- [ ] Give facilities a security-definer function or view that returns only the fields in `matches.shared_fields`. Remove direct facility SELECT access to `wellness_instructors`.
- [ ] Make sure instructors cannot read facility details or any rates.
- Done when: pgTAP or script tests show a facility user cannot retrieve instructor email, phone, address, rates, or unshared fields, and an instructor cannot retrieve facility fees.

**4. Lock down Edge Functions**
- [ ] `send-email`: require an authenticated caller and restrict by role and template. Public flows (new application and inquiry notifications) should send only to the admin address, never to caller-chosen recipients.
- [ ] `docusign` (send action): require a logged-in admin.
- [ ] `docusign` (webhook): deploy with `--no-verify-jwt`, implement real HMAC verification with DocuSign Connect, and document this in the README.
- [ ] `run-daily-jobs`: accept only the service-role key.

**5. Fix DocuSign authentication**
- [ ] Replace the static access token with JWT Grant (integration key, user ID, RSA key) and token caching/refresh inside the function.
- [ ] Update the README with the consent and key setup steps.

**6. Cron secrets**
- [ ] Replace `ALTER DATABASE ... SET app.service_role_key` with Supabase Vault (or whatever current Supabase docs recommend). Update migration 004 comments and the README.

## Phase 2 — Bugs and data integrity

- [ ] `run-daily-jobs`: fix the `siteUrl` construction so admin email links point to the real GitHub Pages site (add a `site_url` setting or env var).
- [ ] Make payment reminders catch-up safe: send if the reminder window has been entered and no reminder was logged for that due date, instead of matching one exact day.
- [ ] Verify the credential expiry query actually restricts to approved instructors.
- [ ] Add a database trigger that blocks UPDATE/DELETE on contracts with `status = 'signed'`.
- [ ] Contracts: stop sending .txt to DocuSign. Render the contract to PDF (or HTML-to-PDF) and keep the anchor-tag approach working or switch to explicit tab positions. Fail loudly if any `[variable]` placeholders remain unresolved in the content.
- [ ] Replace the hardcoded compliance checklist labels with a settings-managed list (spec Settings section 7), keeping existing checked rows intact.
- [ ] Facility inquiry: rename or remove the "participant considerations" field (`medical_considerations` column) so the platform does not invite participant health information. Add a notice telling facilities not to include participant details. Migrate the column.

## Phase 3 — Tests

- [ ] RLS tests for every role (admin, instructor, facility, anonymous) covering each business rule above.
- [ ] Edge Function tests: unauthorized calls rejected, webhook signature verification, dedup logic in daily jobs.
- [ ] A short Playwright smoke test per portal: apply as instructor, approve, create match, facility sees only shared fields.

## Phase 4 — Payments (needs decisions first)

- [ ] Before writing code, verify whether Snipcart supports recurring monthly ACH for facilities, and report findings with sources.
- [ ] Decide how Admin pays instructors by ACH (separate from Snipcart, which cannot send payouts). Present options with trade-offs; do not build until the owner chooses.
- [ ] Flag for the owner's attorney: money movement in both directions, ACH authorization language, and entity type.

## Phase 5 — Remaining spec items

- [ ] Admin Payments page with pre-calculated instructor amounts and manual adjustment (after the payment decision).
- [ ] Session scheduling and session reminder emails (templates already exist in `send-email`).
- [ ] Settings items listed in the spec but not yet in the UI (default session rate, default instructor pay, compliance items editor).
- [ ] Update the README and spec revision log to match the final code.