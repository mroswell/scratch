-- ============================================================
-- MORE LIFE PLATFORM — SUPABASE SCHEMA
-- Run this in your Supabase SQL editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── PROFILES ───────────────────────────────────────────────
-- Extends Supabase auth.users with role information
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  role TEXT NOT NULL CHECK (role IN ('admin', 'instructor', 'facility')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SITE SETTINGS ──────────────────────────────────────────
CREATE TABLE site_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert defaults
INSERT INTO site_settings (key, value) VALUES
  ('business_name', 'More Life'),
  ('business_address', ''),
  ('business_entity_type', ''),
  ('admin_phone', '1-786-346-6722'),
  ('admin_email', ''),
  ('contract_signatory_name', ''),
  ('contract_signatory_title', ''),
  ('logo_url', ''),
  ('expiry_warning_days_first', '60'),
  ('expiry_warning_days_second', '30'),
  ('availability_notice_text', 'You must also call us at {phone} to notify us directly of any schedule changes. Platform updates alone are not sufficient.'),
  ('credit_refund_policy', 'In the event that a scheduled Wellness Instructor is unable to fulfill a session for any reason, the Facility will receive a credit toward a future invoice, or a pro-rated refund for that session.'),
  ('cancellation_policy', 'We ask that you provide 48 hours notice when possible so we may notify the facility in a timely manner. We understand that emergencies occur and this request is a professional courtesy, not a penalty trigger.');

-- ─── WELLNESS INSTRUCTORS ────────────────────────────────────
CREATE TABLE wellness_instructors (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  legal_name TEXT NOT NULL,
  nickname TEXT,
  business_name TEXT,
  phone TEXT,
  email TEXT NOT NULL,
  address TEXT,
  headshot_url TEXT,
  bio TEXT,
  years_experience INTEGER,
  teletraining BOOLEAN DEFAULT FALSE,
  drive_minutes INTEGER,
  space_requirements TEXT,
  service_area_lat DECIMAL,
  service_area_lng DECIMAL,
  service_area_radius_km DECIMAL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── INSTRUCTOR SERVICES ─────────────────────────────────────
CREATE TABLE instructor_services (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  instructor_id UUID REFERENCES wellness_instructors(id) ON DELETE CASCADE,
  service_name TEXT NOT NULL
);

-- ─── INSTRUCTOR SOCIAL MEDIA ─────────────────────────────────
CREATE TABLE instructor_social_media (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  instructor_id UUID REFERENCES wellness_instructors(id) ON DELETE CASCADE,
  platform TEXT NOT NULL,
  url TEXT NOT NULL
);

-- ─── INSTRUCTOR CREDENTIALS ──────────────────────────────────
CREATE TABLE instructor_credentials (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  instructor_id UUID REFERENCES wellness_instructors(id) ON DELETE CASCADE,
  credential_type TEXT NOT NULL CHECK (credential_type IN ('insurance', 'certification', 'license')),
  name TEXT NOT NULL,
  issuing_body TEXT,
  number TEXT,
  expiry_date DATE,
  file_url TEXT, -- private storage path, never exposed publicly
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'expired', 'expiring_soon')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── INSTRUCTOR AVAILABILITY ─────────────────────────────────
CREATE TABLE instructor_availability (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  instructor_id UUID REFERENCES wellness_instructors(id) ON DELETE CASCADE,
  day_of_week TEXT NOT NULL CHECK (day_of_week IN ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── FACILITIES ──────────────────────────────────────────────
CREATE TABLE facilities (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  facility_name TEXT NOT NULL,
  director_name TEXT NOT NULL,
  phone TEXT,
  email TEXT NOT NULL,
  address TEXT,
  facility_type TEXT NOT NULL CHECK (facility_type IN ('senior_daycare', 'medical_center')),
  services_desired TEXT,
  preferred_schedule TEXT,
  medical_considerations TEXT,
  budget_range TEXT, -- admin only
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── MATCHES ─────────────────────────────────────────────────
CREATE TABLE matches (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  instructor_id UUID REFERENCES wellness_instructors(id) ON DELETE CASCADE,
  facility_id UUID REFERENCES facilities(id) ON DELETE CASCADE,
  shared_fields JSONB DEFAULT '{}', -- checkbox selections admin made
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── CONTRACT TEMPLATES ───────────────────────────────────────
CREATE TABLE contract_templates (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  template_type TEXT NOT NULL CHECK (template_type IN ('facility', 'instructor')),
  content TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Insert default contract template content
INSERT INTO contract_templates (template_type, content) VALUES
('facility', '# FACILITY SERVICES AGREEMENT

**More Life Wellness Coordination Platform**
*DRAFT — Subject to Attorney Review*

---

## 1. Parties

This Facility Services Agreement (the "Agreement") is entered into as of **{{contract_start_date}}**, by and between:

**Service Provider:** {{business_name}}, a {{business_entity_type}}, located at {{business_address}} (hereinafter "More Life" or "the Company").

**Facility:** {{facility_name}}, a {{facility_type}}, located at {{facility_address}} (hereinafter "Facility"). The authorized representative is {{director_name}}, {{director_title}}.

---

## 2. Purpose & Scope of Services

More Life agrees to coordinate and facilitate the delivery of group wellness sessions to the Facility''s adult and senior participants. Services include: {{services_authorized}}.

All sessions will be conducted on-site at the Facility by a vetted Wellness Instructor arranged by More Life. Sessions are group format and one (1) hour in duration.

---

## 3. Session Schedule

Sessions will be conducted **{{sessions_per_week}}** time(s) per week on agreed days and times to be confirmed upon scheduling.

---

## 4. Fees & Payment Terms

The Facility agrees to pay More Life a monthly service fee of **{{monthly_fee}}** (USD), due in advance on the **{{payment_due_date}}** of each month.

**Credit/Refund Policy:** {{credit_refund_policy}}

---

## 5. Cancellations

**Facility Cancellations:** The Facility may cancel a scheduled session by providing at least {{notice_period}} hours written notice.

**Instructor Cancellations:** {{cancellation_policy}}

---

## 6. Term & Termination

This Agreement commences on {{contract_start_date}} for an initial term of {{contract_duration}}, renewing automatically for {{renewal_period}} terms unless either party provides {{termination_notice_days}} days written notice.

Either party may terminate without cause upon {{termination_notice_days}} days written notice.

---

## 7. Relationship of Parties

More Life is an independent contractor. Wellness Instructors are independent contractors engaged by More Life. Nothing herein creates an employment relationship.

---

## 8. Governing Law

This Agreement shall be governed by the laws of the State of {{governing_state}}.

---

## 9. Signatures

**More Life:**

Signature: ______________________________

Name: {{signatory_name}} | Title: {{signatory_title}} | Date: ___________

**Facility:**

Signature: ______________________________

Name: {{director_name}} | Title: {{director_title}} | Date: ___________
'),
('instructor', '# WELLNESS INSTRUCTOR AGREEMENT

**More Life Wellness Coordination Platform**
*DRAFT — Subject to Attorney Review*

---

## 1. Parties

This Wellness Instructor Agreement (the "Agreement") is entered into as of **{{contract_start_date}}**, by and between:

**Company:** {{business_name}}, a {{business_entity_type}}, located at {{business_address}} (hereinafter "More Life").

**Wellness Instructor:** {{instructor_legal_name}}, an independent contractor (hereinafter "Instructor").

---

## 2. Nature of Engagement

More Life engages the Instructor as an **independent contractor** to deliver wellness sessions at facilities arranged by More Life. This Agreement does not create an employment relationship.

---

## 3. Authorized Services

The Instructor is authorized to deliver: **{{services_authorized}}**.

Teletraining authorized: **{{teletraining_authorized}}**.

All sessions are in-person at the assigned facility, group format, one (1) hour duration.

---

## 4. Geographic Scope

The Instructor agrees to travel to assigned facilities within their defined service area. **No geographic exclusivity** is granted under this Agreement.

---

## 5. Compensation

**Rate:** {{pay_rate}}

**Pay Schedule:** {{pay_schedule}} (default: biweekly, negotiable).

The Instructor is solely responsible for all taxes on compensation received. More Life will issue Form 1099 as required by law.

---

## 6. Scheduling & Cancellations

**Availability Updates:** The Instructor must keep availability current on the platform AND notify More Life by phone at {{admin_phone}}.

**Cancellations:** {{cancellation_policy}}

---

## 7. Credentials & Insurance

The Instructor maintains valid certifications: **{{certifications}}** and valid professional liability insurance (minimum {{insurance_minimum}}) throughout this Agreement. Certificates must be on file with More Life at all times.

---

## 8. Confidentiality & Non-Solicitation

The Instructor agrees to keep all More Life business information confidential. During this Agreement and for {{non_solicitation_period}} following termination, the Instructor agrees not to directly solicit facilities introduced through More Life without written consent.

---

## 9. Term & Termination

Commences {{contract_start_date}} for {{contract_duration}}, renewing automatically for {{renewal_period}} terms unless {{termination_notice_days}} days written notice is provided.

---

## 10. Governing Law

This Agreement shall be governed by the laws of the State of {{governing_state}}.

---

## 11. Signatures

**More Life:**

Signature: ______________________________

Name: {{signatory_name}} | Title: {{signatory_title}} | Date: ___________

**Wellness Instructor:**

Signature: ______________________________

Legal Name: {{instructor_legal_name}} | Preferred Name: {{instructor_preferred_name}} | Date: ___________
');

-- ─── CONTRACTS ───────────────────────────────────────────────
CREATE TABLE contracts (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  contract_type TEXT NOT NULL CHECK (contract_type IN ('facility', 'instructor')),
  party_id UUID NOT NULL, -- facility_id or instructor_id
  content TEXT NOT NULL, -- rendered contract with fields filled
  dynamic_fields JSONB DEFAULT '{}',
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'signed')),
  file_url TEXT, -- signed PDF storage path
  sent_at TIMESTAMPTZ,
  signed_at TIMESTAMPTZ,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── NOTIFICATIONS LOG ───────────────────────────────────────
CREATE TABLE notification_log (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  notification_type TEXT NOT NULL,
  recipient_email TEXT NOT NULL,
  subject TEXT,
  status TEXT DEFAULT 'sent',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── ADMIN COMMENTS ──────────────────────────────────────────
CREATE TABLE admin_comments (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('instructor', 'facility', 'match', 'contract')),
  entity_id UUID NOT NULL,
  comment TEXT NOT NULL,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- ROW LEVEL SECURITY POLICIES
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE wellness_instructors ENABLE ROW LEVEL SECURITY;
ALTER TABLE instructor_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE instructor_social_media ENABLE ROW LEVEL SECURITY;
ALTER TABLE instructor_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE instructor_availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE facilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE contract_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_comments ENABLE ROW LEVEL SECURITY;

-- Helper function to get current user role
CREATE OR REPLACE FUNCTION get_user_role()
RETURNS TEXT AS $$
  SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER;

-- ─── PROFILES POLICIES ───────────────────────────────────────
CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT USING (id = auth.uid());

CREATE POLICY "Admin can read all profiles"
  ON profiles FOR SELECT USING (get_user_role() = 'admin');

CREATE POLICY "Admin can insert profiles"
  ON profiles FOR INSERT WITH CHECK (get_user_role() = 'admin');

-- ─── SITE SETTINGS POLICIES ──────────────────────────────────
CREATE POLICY "Anyone authenticated can read site settings"
  ON site_settings FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Only admin can modify site settings"
  ON site_settings FOR ALL USING (get_user_role() = 'admin');

-- ─── WELLNESS INSTRUCTORS POLICIES ───────────────────────────
CREATE POLICY "Admin can do everything with instructors"
  ON wellness_instructors FOR ALL USING (get_user_role() = 'admin');

CREATE POLICY "Instructors can read own record"
  ON wellness_instructors FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Instructors can update own record"
  ON wellness_instructors FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "Anyone can insert instructor application"
  ON wellness_instructors FOR INSERT WITH CHECK (true);

-- ─── INSTRUCTOR SERVICES POLICIES ────────────────────────────
CREATE POLICY "Admin can manage instructor services"
  ON instructor_services FOR ALL USING (get_user_role() = 'admin');

CREATE POLICY "Instructors can manage own services"
  ON instructor_services FOR ALL USING (
    instructor_id IN (SELECT id FROM wellness_instructors WHERE user_id = auth.uid())
  );

-- ─── INSTRUCTOR SOCIAL MEDIA POLICIES ────────────────────────
-- Admin only - never exposed to facilities or other instructors
CREATE POLICY "Admin only - social media"
  ON instructor_social_media FOR ALL USING (get_user_role() = 'admin');

CREATE POLICY "Instructors can manage own social media"
  ON instructor_social_media FOR ALL USING (
    instructor_id IN (SELECT id FROM wellness_instructors WHERE user_id = auth.uid())
  );

-- ─── INSTRUCTOR CREDENTIALS POLICIES ─────────────────────────
-- Admin only for file access - instructors can see status only
CREATE POLICY "Admin can manage all credentials"
  ON instructor_credentials FOR ALL USING (get_user_role() = 'admin');

CREATE POLICY "Instructors can see own credential status (no file_url)"
  ON instructor_credentials FOR SELECT USING (
    instructor_id IN (SELECT id FROM wellness_instructors WHERE user_id = auth.uid())
  );

-- ─── INSTRUCTOR AVAILABILITY POLICIES ────────────────────────
CREATE POLICY "Admin can manage all availability"
  ON instructor_availability FOR ALL USING (get_user_role() = 'admin');

CREATE POLICY "Instructors can manage own availability"
  ON instructor_availability FOR ALL USING (
    instructor_id IN (SELECT id FROM wellness_instructors WHERE user_id = auth.uid())
  );

-- ─── FACILITIES POLICIES ─────────────────────────────────────
CREATE POLICY "Admin can do everything with facilities"
  ON facilities FOR ALL USING (get_user_role() = 'admin');

CREATE POLICY "Facilities can read own record"
  ON facilities FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Facilities can update own record"
  ON facilities FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "Anyone can submit facility inquiry"
  ON facilities FOR INSERT WITH CHECK (true);

-- ─── MATCHES POLICIES ────────────────────────────────────────
-- Admin only - neither instructors nor facilities can see matches
CREATE POLICY "Admin only - matches"
  ON matches FOR ALL USING (get_user_role() = 'admin');

-- Facilities can see their own shared profiles via matches (limited fields only)
CREATE POLICY "Facilities can see their own match shared_fields"
  ON matches FOR SELECT USING (
    facility_id IN (SELECT id FROM facilities WHERE user_id = auth.uid())
  );

-- ─── CONTRACT TEMPLATES POLICIES ─────────────────────────────
CREATE POLICY "Admin only - contract templates"
  ON contract_templates FOR ALL USING (get_user_role() = 'admin');

-- ─── CONTRACTS POLICIES ──────────────────────────────────────
CREATE POLICY "Admin can manage all contracts"
  ON contracts FOR ALL USING (get_user_role() = 'admin');

-- Instructors can view (not edit) their own signed contract
CREATE POLICY "Instructors can view own contract"
  ON contracts FOR SELECT USING (
    contract_type = 'instructor' AND
    party_id IN (SELECT id FROM wellness_instructors WHERE user_id = auth.uid()) AND
    status = 'signed'
  );

-- ─── NOTIFICATION LOG POLICIES ───────────────────────────────
CREATE POLICY "Admin only - notification log"
  ON notification_log FOR ALL USING (get_user_role() = 'admin');

-- ─── ADMIN COMMENTS POLICIES ─────────────────────────────────
CREATE POLICY "Admin only - comments"
  ON admin_comments FOR ALL USING (get_user_role() = 'admin');

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
-- Run these in Supabase Storage settings or via the dashboard:
-- 1. Create bucket: "headshots" — PUBLIC (headshots are not sensitive)
-- 2. Create bucket: "private-docs" — PRIVATE (insurance certs, signed contracts)
-- 3. Set private-docs bucket policy: only service_role can access

-- ============================================================
-- FUNCTIONS
-- ============================================================

-- Auto-update updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_instructors_updated_at
  BEFORE UPDATE ON wellness_instructors
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_facilities_updated_at
  BEFORE UPDATE ON facilities
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Function to check expiring credentials (called by cron or on login)
CREATE OR REPLACE FUNCTION get_expiring_credentials(days_ahead INTEGER)
RETURNS TABLE (
  instructor_id UUID,
  instructor_name TEXT,
  instructor_email TEXT,
  credential_type TEXT,
  credential_name TEXT,
  expiry_date DATE,
  days_until_expiry INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    ic.instructor_id,
    wi.legal_name,
    wi.email,
    ic.credential_type,
    ic.name,
    ic.expiry_date,
    (ic.expiry_date - CURRENT_DATE)::INTEGER
  FROM instructor_credentials ic
  JOIN wellness_instructors wi ON wi.id = ic.instructor_id
  WHERE ic.expiry_date IS NOT NULL
    AND ic.expiry_date <= (CURRENT_DATE + days_ahead)
    AND ic.expiry_date >= CURRENT_DATE
  ORDER BY ic.expiry_date ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
