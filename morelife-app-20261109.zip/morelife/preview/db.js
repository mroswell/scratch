// preview/db.js
// ============================================================
// MORE LIFE — LOCAL PREVIEW QUERY ENGINE
// Builds the in-memory SQLite DB and translates the Supabase-style
// query descriptors (produced by js/local-shim.js) into SQLite SQL,
// enforcing the Row-Level-Security privacy boundaries in code.
// Pure/testable: no HTTP here (see server.js for the HTTP wrapper).
// ============================================================

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const { seed } = require('./seed');

// ─── DB construction ─────────────────────────────────────────
// dbPath defaults to ':memory:' (ephemeral — used by the tests and the
// original in-memory mode). Pass a file path (see server.js) to persist
// across restarts: the schema + demo data are seeded only when the file
// is brand new, so a persistent DB keeps whatever the user changed.
function buildDb(dbPath = ':memory:') {
  const db = new Database(dbPath);
  db.pragma('foreign_keys = OFF');
  const initialized = db.prepare(
    "SELECT name FROM sqlite_master WHERE type='table' AND name='wellness_instructors'"
  ).get();
  if (!initialized) {
    const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    db.exec(schema);
    seed(db);
  }
  return db;
}

// ─── Table metadata ──────────────────────────────────────────
const PK = { site_settings: 'key' }; // default PK is 'id'
function pkOf(table) { return PK[table] || 'id'; }

const JSON_COLUMNS = { matches: ['shared_fields'], contracts: ['dynamic_fields'] };
const UPDATED_AT_TABLES = new Set(['wellness_instructors', 'facilities', 'service_categories', 'site_settings']);

// Relationships used by the two embedded (nested) selects in the app.
// key: `${parentTable}.${relationName}`
const REL = {
  'matches.wellness_instructors':             { type: 'one',  childTable: 'wellness_instructors',    parentKey: 'instructor_id', childKey: 'id' },
  'wellness_instructors.instructor_services':   { type: 'many', childTable: 'instructor_services',    parentKey: 'id',            childKey: 'instructor_id' },
  'wellness_instructors.instructor_credentials':{ type: 'many', childTable: 'instructor_credentials', parentKey: 'id',            childKey: 'instructor_id' },
};

// ─── select-string parser (handles nested parens) ────────────
// "id, shared_fields, wellness_instructors(id, legal_name, instructor_services(service_name))"
// -> { cols:['id','shared_fields'], embeds:[{ name, select:{cols, embeds} }] }
function parseSelect(str) {
  const cols = [];
  const embeds = [];
  if (!str) return { cols: ['*'], embeds };
  let depth = 0, token = '';
  const tokens = [];
  for (const ch of str) {
    if (ch === '(') { depth++; token += ch; }
    else if (ch === ')') { depth--; token += ch; }
    else if (ch === ',' && depth === 0) { tokens.push(token); token = ''; }
    else token += ch;
  }
  if (token.trim()) tokens.push(token);
  for (let t of tokens) {
    t = t.trim();
    if (!t) continue;
    const paren = t.indexOf('(');
    if (paren === -1) { cols.push(t); continue; }
    const name = t.slice(0, paren).trim();
    const inner = t.slice(paren + 1, t.lastIndexOf(')'));
    embeds.push({ name, select: parseSelect(inner) });
  }
  return { cols: cols.length ? cols : ['*'], embeds };
}

// ─── value coercion for writes ───────────────────────────────
function coerceWrite(value) {
  if (value === true) return 1;
  if (value === false) return 0;
  if (value && typeof value === 'object') return JSON.stringify(value);
  return value;
}
function coerceFilterVal(v) {
  if (v === true) return 1;
  if (v === false) return 0;
  return v;
}

// ─── Row-Level-Security emulation ────────────────────────────
// Returns one of: { all:true } | { deny:true } | { where, params }
function readScope(table, role, userId) {
  if (role === 'admin') return { all: true };
  switch (table) {
    case 'site_settings':
    case 'service_categories':
      return { all: true }; // public/all-authenticated read in the real policies
    case 'profiles':
      return { where: 'id = ?', params: [userId] };
    case 'wellness_instructors':
      return role === 'instructor' ? { where: 'user_id = ?', params: [userId] } : { deny: true };
    case 'instructor_services':
    case 'instructor_social_media':
    case 'instructor_credentials':
    case 'instructor_availability':
      return role === 'instructor'
        ? { where: 'instructor_id IN (SELECT id FROM wellness_instructors WHERE user_id = ?)', params: [userId] }
        : { deny: true };
    case 'facilities':
      return role === 'facility' ? { where: 'user_id = ?', params: [userId] } : { deny: true };
    case 'matches':
      return role === 'facility'
        ? { where: 'facility_id IN (SELECT id FROM facilities WHERE user_id = ?)', params: [userId] }
        : { deny: true };
    case 'contracts':
      return role === 'instructor'
        ? { where: "contract_type = 'instructor' AND status = 'signed' AND party_id IN (SELECT id FROM wellness_instructors WHERE user_id = ?)", params: [userId] }
        : { deny: true };
    default:
      // contract_templates, admin_comments, notification_log, instructor_compliance, auth_users
      return { deny: true };
  }
}

// Columns to hide from non-admin callers (defence in depth).
const RESTRICTED_COLUMNS = {
  instructor_credentials: ['file_url'],          // credential files are admin-only
  matches: ['facility_monthly_rate', 'instructor_monthly_rate'], // rates are admin-only
};
function stripRestricted(table, role, row) {
  if (role === 'admin' || !row) return row;
  const hide = RESTRICTED_COLUMNS[table];
  if (!hide) return row;
  const out = { ...row };
  hide.forEach(c => delete out[c]);
  return out;
}

function canWrite(table, op, role) {
  if (role === 'admin') return true;
  if (op === 'insert') {
    // Public application / inquiry / self-signup paths
    return ['wellness_instructors', 'instructor_services', 'instructor_social_media',
      'instructor_credentials', 'instructor_availability', 'facilities', 'profiles'].includes(table);
  }
  if (op === 'update') {
    if (table === 'wellness_instructors') return role === 'instructor';
    if (table === 'facilities') return role === 'facility';
    return ['instructor_services', 'instructor_social_media', 'instructor_credentials', 'instructor_availability'].includes(table) && role === 'instructor';
  }
  if (op === 'delete') {
    return ['instructor_services', 'instructor_social_media', 'instructor_credentials', 'instructor_availability'].includes(table) && role === 'instructor';
  }
  return false;
}

// ─── WHERE builder ───────────────────────────────────────────
function buildWhere(descriptor, scope) {
  const clauses = [];
  const params = [];
  if (scope && scope.where) { clauses.push('(' + scope.where + ')'); params.push(...scope.params); }
  for (const f of descriptor.filters || []) {
    if (f.op === 'eq') { clauses.push(`${f.col} = ?`); params.push(coerceFilterVal(f.val)); }
    else if (f.op === 'in') {
      const arr = Array.isArray(f.val) ? f.val : [f.val];
      clauses.push(`${f.col} IN (${arr.map(() => '?').join(',')})`);
      params.push(...arr.map(coerceFilterVal));
    }
  }
  if (descriptor.orFilter) {
    const ors = [];
    for (const clause of descriptor.orFilter.split(',')) {
      const [col, op, ...rest] = clause.split('.');
      const val = rest.join('.');
      if (op === 'ilike' || op === 'like') { ors.push(`${col} LIKE ?`); params.push(val); }
      else if (op === 'eq') { ors.push(`${col} = ?`); params.push(val); }
    }
    if (ors.length) clauses.push('(' + ors.join(' OR ') + ')');
  }
  return { sql: clauses.length ? ' WHERE ' + clauses.join(' AND ') : '', params };
}

// ─── embed resolution ────────────────────────────────────────
function resolveEmbeds(db, parentTable, rows, embeds, role) {
  for (const emb of embeds) {
    const rel = REL[`${parentTable}.${emb.name}`];
    for (const row of rows) {
      if (!rel) { row[emb.name] = rel && rel.type === 'one' ? null : []; continue; }
      const keyVal = row[rel.parentKey];
      let children = db.prepare(`SELECT * FROM ${rel.childTable} WHERE ${rel.childKey} = ?`).all(keyVal);
      children = children.map(c => stripRestricted(rel.childTable, role, c));
      resolveEmbeds(db, rel.childTable, children, emb.select.embeds, role);
      const projected = children.map(c => project(c, emb.select, rel.childTable));
      row[emb.name] = rel.type === 'one' ? (projected[0] || null) : projected;
    }
  }
  return rows;
}

// keep only requested columns (+ embed names). '*' keeps everything.
function project(row, select, table) {
  if (!row) return row;
  // parse JSON columns
  const jsonCols = JSON_COLUMNS[table] || [];
  for (const jc of jsonCols) {
    if (typeof row[jc] === 'string') { try { row[jc] = JSON.parse(row[jc]); } catch (_) { /* leave */ } }
  }
  const embedNames = select.embeds.map(e => e.name);
  if (select.cols.includes('*')) return row;
  const out = {};
  for (const c of select.cols) if (c in row) out[c] = row[c];
  for (const n of embedNames) if (n in row) out[n] = row[n];
  return out;
}

// ─── main query runner ───────────────────────────────────────
// ctx = { role, userId }
function runQuery(db, descriptor, ctx) {
  const { table, op } = descriptor;
  const role = ctx.role || 'anon';
  const userId = ctx.userId || null;
  try {
    if (op === 'select') return runSelect(db, descriptor, role, userId);
    if (op === 'insert') return runInsert(db, descriptor, role, userId);
    if (op === 'update') return runUpdate(db, descriptor, role, userId);
    if (op === 'upsert') return runUpsert(db, descriptor, role, userId);
    if (op === 'delete') return runDelete(db, descriptor, role, userId);
    return { data: null, error: { message: 'Unsupported op: ' + op }, count: null };
  } catch (e) {
    return { data: null, error: { message: e.message }, count: null };
  }
}

function runSelect(db, descriptor, role, userId) {
  const { table } = descriptor;
  const scope = readScope(table, role, userId);
  const select = parseSelect(descriptor.columns || '*');

  if (scope.deny) {
    if (descriptor.head) return { data: null, error: null, count: 0 };
    if (descriptor.single) return { data: null, error: { message: 'No rows found' }, count: null };
    if (descriptor.maybeSingle) return { data: null, error: null, count: null };
    return { data: [], error: null, count: 0 };
  }

  const where = buildWhere(descriptor, scope.all ? null : scope);

  // Count / head query
  if (descriptor.head || descriptor.count === 'exact') {
    const row = db.prepare(`SELECT COUNT(*) AS c FROM ${table}${where.sql}`).get(...where.params);
    if (descriptor.head) return { data: null, error: null, count: row.c };
    // count + rows both requested
  }

  let sql = `SELECT * FROM ${table}${where.sql}`;
  if (descriptor.order) sql += ` ORDER BY ${descriptor.order.col} ${descriptor.order.ascending ? 'ASC' : 'DESC'}`;
  if (descriptor.limit != null) sql += ` LIMIT ${Number(descriptor.limit)}`;

  let rows = db.prepare(sql).all(...where.params);
  rows = rows.map(r => stripRestricted(table, role, r));
  resolveEmbeds(db, table, rows, select.embeds, role);
  rows = rows.map(r => project(r, select, table));

  if (descriptor.single) {
    if (rows.length === 1) return { data: rows[0], error: null, count: null };
    return { data: null, error: { message: rows.length === 0 ? 'No rows found' : 'Multiple rows found' }, count: null };
  }
  if (descriptor.maybeSingle) {
    if (rows.length <= 1) return { data: rows[0] || null, error: null, count: null };
    return { data: null, error: { message: 'Multiple rows found' }, count: null };
  }
  const count = descriptor.count === 'exact' ? rows.length : null;
  return { data: rows, error: null, count };
}

function prepRow(table, row) {
  const out = {};
  for (const [k, v] of Object.entries(row)) out[k] = coerceWrite(v);
  if (!(pkOf(table) in out) && pkOf(table) === 'id') out.id = crypto.randomUUID();
  return out;
}

function insertOne(db, table, row) {
  const prepared = prepRow(table, row);
  const cols = Object.keys(prepared);
  db.prepare(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
    .run(...cols.map(c => prepared[c]));
  return prepared[pkOf(table)];
}

function runInsert(db, descriptor, role, userId) {
  const { table } = descriptor;
  if (!canWrite(table, 'insert', role)) return { data: null, error: { message: `Not authorized to insert into ${table}` }, count: null };
  const values = Array.isArray(descriptor.values) ? descriptor.values : [descriptor.values];
  const ids = values.map(v => insertOne(db, table, v));
  if (descriptor.returning) {
    const rows = ids.map(id => db.prepare(`SELECT * FROM ${table} WHERE ${pkOf(table)} = ?`).get(id));
    const select = parseSelect(descriptor.columns || '*');
    const projected = rows.map(r => project(r, select, table));
    if (descriptor.single) return { data: projected[0] || null, error: null, count: null };
    return { data: projected, error: null, count: null };
  }
  return { data: null, error: null, count: null };
}

function runUpdate(db, descriptor, role, userId) {
  const { table } = descriptor;
  if (!canWrite(table, 'update', role)) return { data: null, error: { message: `Not authorized to update ${table}` }, count: null };
  const scope = role === 'admin' ? { all: true } : readScope(table, role, userId);
  if (scope.deny) return { data: null, error: { message: `Not authorized to update ${table}` }, count: null };

  const patch = { ...descriptor.values };
  if (UPDATED_AT_TABLES.has(table)) patch.updated_at = new Date().toISOString();
  const setCols = Object.keys(patch);
  const setSql = setCols.map(c => `${c} = ?`).join(', ');
  const setParams = setCols.map(c => coerceWrite(patch[c]));

  const where = buildWhere(descriptor, scope.all ? null : scope);
  db.prepare(`UPDATE ${table} SET ${setSql}${where.sql}`).run(...setParams, ...where.params);

  if (descriptor.returning) {
    const rows = db.prepare(`SELECT * FROM ${table}${where.sql}`).all(...where.params).map(r => stripRestricted(table, role, r));
    const select = parseSelect(descriptor.columns || '*');
    const projected = rows.map(r => project(r, select, table));
    if (descriptor.single) return { data: projected[0] || null, error: null, count: null };
    return { data: projected, error: null, count: null };
  }
  return { data: null, error: null, count: null };
}

function runUpsert(db, descriptor, role, userId) {
  const { table } = descriptor;
  // Only site_settings is upserted in the app (admin only).
  if (!canWrite(table, 'update', role) && !canWrite(table, 'insert', role)) {
    return { data: null, error: { message: `Not authorized to upsert ${table}` }, count: null };
  }
  if (role !== 'admin' && table === 'site_settings') {
    return { data: null, error: { message: 'Not authorized to upsert site_settings' }, count: null };
  }
  const values = Array.isArray(descriptor.values) ? descriptor.values : [descriptor.values];
  const pk = pkOf(table);
  for (const v of values) {
    const prepared = prepRow(table, v);
    const cols = Object.keys(prepared);
    const updateCols = cols.filter(c => c !== pk);
    const sql = `INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})` +
      ` ON CONFLICT(${pk}) DO UPDATE SET ${updateCols.map(c => `${c} = excluded.${c}`).join(', ')}`;
    db.prepare(sql).run(...cols.map(c => prepared[c]));
  }
  return { data: null, error: null, count: null };
}

function runDelete(db, descriptor, role, userId) {
  const { table } = descriptor;
  if (!canWrite(table, 'delete', role)) return { data: null, error: { message: `Not authorized to delete from ${table}` }, count: null };
  const scope = role === 'admin' ? { all: true } : readScope(table, role, userId);
  if (scope.deny) return { data: null, error: { message: `Not authorized to delete from ${table}` }, count: null };
  const where = buildWhere(descriptor, scope.all ? null : scope);
  if (!where.sql) return { data: null, error: { message: 'Refusing unfiltered delete' }, count: null };
  db.prepare(`DELETE FROM ${table}${where.sql}`).run(...where.params);
  return { data: null, error: null, count: null };
}

// ─── RPC ─────────────────────────────────────────────────────
function runRpc(db, name, params) {
  if (name === 'get_expiring_credentials') {
    const daysAhead = Number(params?.days_ahead ?? 60);
    const rows = db.prepare(`
      SELECT ic.instructor_id AS instructor_id,
             wi.legal_name     AS instructor_name,
             wi.email          AS instructor_email,
             ic.credential_type AS credential_type,
             ic.name           AS credential_name,
             ic.expiry_date    AS expiry_date,
             CAST(julianday(ic.expiry_date) - julianday('now') AS INTEGER) AS days_until_expiry
      FROM instructor_credentials ic
      JOIN wellness_instructors wi ON wi.id = ic.instructor_id
      WHERE ic.expiry_date IS NOT NULL
        AND ic.expiry_date <= date('now', '+' || ? || ' days')
        AND ic.expiry_date >= date('now')
      ORDER BY ic.expiry_date ASC
    `).all(daysAhead);
    return { data: rows, error: null };
  }
  return { data: null, error: { message: 'Unknown rpc: ' + name } };
}

// ─── Auth ────────────────────────────────────────────────────
function signIn(db, email, password) {
  const user = db.prepare('SELECT id, email FROM auth_users WHERE email = ? AND password = ?').get(email, password);
  if (!user) return { data: null, error: { message: 'Invalid login credentials' } };
  return { data: { user, session: { user, access_token: 'demo-token' } }, error: null };
}

function signUp(db, email, password) {
  const existing = db.prepare('SELECT id FROM auth_users WHERE email = ?').get(email);
  if (existing) return { data: null, error: { message: 'User already registered' } };
  const id = crypto.randomUUID();
  db.prepare('INSERT INTO auth_users (id, email, password, created_at) VALUES (?, ?, ?, ?)')
    .run(id, email, password, new Date().toISOString());
  const user = { id, email };
  return { data: { user, session: { user, access_token: 'demo-token' } }, error: null };
}

module.exports = { buildDb, runQuery, runRpc, signIn, signUp, parseSelect, readScope, canWrite };
