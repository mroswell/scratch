// js/local-shim.js
// ============================================================
// MORE LIFE — LOCAL PREVIEW SHIM (loaded ONLY by preview/server.js,
// which swaps the Supabase CDN <script> for this file on the fly).
// It defines window.supabase so js/app.js's
//   const { createClient } = supabase; const sb = createClient(...)
// transparently gets a local client backed by the SQLite preview API.
// This file is never loaded by the real (GitHub Pages) deployment.
// ============================================================
(function () {
  const SESSION_KEY = 'morelife_demo_session';
  const DEMO_PW = 'demo1234';
  const DEMO = {
    admin:      { email: 'admin@morelife.test',   label: 'Admin',      url: '/admin/dashboard.html' },
    instructor: { email: 'grace@morelife.test',   label: 'Instructor', url: '/instructor/portal.html' },
    facility:   { email: 'sunrise@morelife.test', label: 'Facility',   url: '/facility/portal.html' },
  };

  // ─── session helpers ───────────────────────────────────────
  function getSession() { try { return JSON.parse(localStorage.getItem(SESSION_KEY)); } catch { return null; } }
  function setSession(s) { s ? localStorage.setItem(SESSION_KEY, JSON.stringify(s)) : localStorage.removeItem(SESSION_KEY); }

  async function api(route, body) {
    const s = getSession();
    const headers = { 'Content-Type': 'application/json' };
    if (s && s.user) { headers['x-demo-user-id'] = s.user.id; headers['x-demo-role'] = s.role || 'anon'; }
    const r = await fetch(route, { method: 'POST', headers, body: JSON.stringify(body) });
    return r.json();
  }

  async function roleFor(userId) {
    // profiles is readable by its owner regardless of role header
    const r = await api('/api/query', { table: 'profiles', op: 'select', columns: 'role', filters: [{ col: 'id', op: 'eq', val: userId }], single: true });
    return r.data ? r.data.role : null;
  }

  // ─── query builder (mirrors the Supabase chainable surface) ─
  function from(table) {
    const d = { table, op: 'select', columns: '*', filters: [], orFilter: null, order: null, limit: null, single: false, maybeSingle: false, count: null, head: false, values: null, returning: false };
    const b = {
      select(cols, opts) {
        if (d.op === 'select') { d.columns = cols || '*'; if (opts && opts.count) d.count = opts.count; if (opts && opts.head) d.head = true; }
        else { d.returning = true; d.columns = cols || '*'; } // representation after insert/update
        return b;
      },
      insert(values) { d.op = 'insert'; d.values = values; return b; },
      update(values) { d.op = 'update'; d.values = values; return b; },
      upsert(values) { d.op = 'upsert'; d.values = values; return b; },
      delete() { d.op = 'delete'; return b; },
      eq(col, val) { d.filters.push({ col, op: 'eq', val }); return b; },
      in(col, val) { d.filters.push({ col, op: 'in', val }); return b; },
      or(str) { d.orFilter = str; return b; },
      order(col, opts) { d.order = { col, ascending: opts ? opts.ascending !== false : true }; return b; },
      limit(n) { d.limit = n; return b; },
      single() { d.single = true; return b; },
      maybeSingle() { d.maybeSingle = true; return b; },
      then(resolve, reject) { return api('/api/query', d).then(resolve, reject); },
    };
    return b;
  }

  // ─── auth ──────────────────────────────────────────────────
  const auth = {
    async getSession() { const s = getSession(); return { data: { session: s ? { user: s.user, access_token: 'demo-token' } : null }, error: null }; },
    async getUser() { const s = getSession(); return { data: { user: s ? s.user : null }, error: null }; },
    async signInWithPassword({ email, password }) {
      const r = await api('/api/auth/signin', { email, password });
      if (r.error) return { data: null, error: r.error };
      setSession({ user: r.data.user, role: null });
      const role = await roleFor(r.data.user.id);
      setSession({ user: r.data.user, role });
      updateSwitcher();
      return { data: r.data, error: null };
    },
    async signUp({ email, password }) {
      const r = await api('/api/auth/signup', { email, password });
      if (r.error) return { data: null, error: r.error };
      setSession({ user: r.data.user, role: null });
      updateSwitcher();
      return { data: r.data, error: null };
    },
    async signOut() { setSession(null); updateSwitcher(); return { error: null }; },
    async resetPasswordForEmail() { return { data: {}, error: null }; },
  };

  // ─── storage (fully client-side; no disk) ──────────────────
  const uploads = {};
  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = () => reject(new Error('read failed'));
      fr.readAsDataURL(file);
    });
  }
  const storage = {
    from(bucket) {
      return {
        async upload(path, file) {
          try { uploads[bucket + '/' + path] = await fileToDataUrl(file); return { data: { path }, error: null }; }
          catch (e) { return { data: null, error: { message: e.message } }; }
        },
        getPublicUrl(path) { return { data: { publicUrl: uploads[bucket + '/' + path] || ('/uploads/' + bucket + '/' + path) } }; },
        async createSignedUrl(path) { return { data: { signedUrl: uploads[bucket + '/' + path] || ('/uploads/' + bucket + '/' + path) }, error: null }; },
      };
    },
  };

  // ─── rpc + edge functions ──────────────────────────────────
  async function rpc(name, params) { return api('/api/rpc', { name, params }); }
  const functions = { async invoke(name, opts) { console.log('[preview] email stub →', name, opts && opts.body); return { data: null, error: null }; } };

  function createLocalClient() { return { from, auth, storage, rpc, functions }; }

  // Expose as the global the app expects.
  window.supabase = { createClient: () => createLocalClient() };
  window.__MORELIFE_LOCAL__ = true;

  // ─── role switcher UI ──────────────────────────────────────
  let switcherEl = null;
  function updateSwitcher() {
    if (!switcherEl) return;
    const s = getSession();
    const who = s && s.user ? `${s.user.email}${s.role ? ' · ' + s.role : ''}` : 'not signed in';
    switcherEl.querySelector('.ml-who').textContent = who;
  }
  async function switchTo(role) {
    await auth.signInWithPassword({ email: DEMO[role].email, password: DEMO_PW });
    window.location.href = DEMO[role].url;
  }
  function buildSwitcher() {
    if (document.getElementById('ml-switcher')) return;
    const el = document.createElement('div');
    el.id = 'ml-switcher';
    el.innerHTML = `
      <style>
        #ml-switcher{position:fixed;top:10px;right:10px;z-index:99999;background:#111;color:#fff;
          border-radius:10px;padding:8px 10px;font:12px/1.3 system-ui,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.25);opacity:.95}
        #ml-switcher .ml-title{font-weight:700;letter-spacing:.02em}
        #ml-switcher .ml-who{opacity:.7;margin:2px 0 6px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        #ml-switcher button{border:0;border-radius:6px;padding:4px 8px;margin:0 3px 0 0;cursor:pointer;font:600 11px system-ui;background:#2d6cf6;color:#fff}
        #ml-switcher button.ghost{background:#333}
        #ml-switcher .ml-tag{display:inline-block;background:#2d6cf6;border-radius:5px;padding:1px 5px;font-size:10px;margin-left:6px;vertical-align:1px}
      </style>
      <div class="ml-title">LOCAL PREVIEW<span class="ml-tag">SQLite</span></div>
      <div class="ml-who"></div>
      <div>
        <button data-role="admin">Admin</button>
        <button data-role="instructor">Instructor</button>
        <button data-role="facility">Facility</button>
        <button class="ghost" data-act="signout">Sign out</button>
      </div>`;
    document.body.appendChild(el);
    switcherEl = el;
    el.querySelectorAll('button[data-role]').forEach(btn => btn.addEventListener('click', () => switchTo(btn.dataset.role)));
    el.querySelector('[data-act="signout"]').addEventListener('click', async () => { await auth.signOut(); window.location.href = '/index.html'; });
    updateSwitcher();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildSwitcher);
  else buildSwitcher();
})();
