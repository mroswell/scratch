-- ============================================================
-- MORE LIFE — LOCAL PREVIEW SCHEMA (SQLite)
-- A faithful SQLite translation of supabase/migrations 001 + 002 + 003.
-- Used ONLY by the throwaway local preview (preview/server.js).
-- Differences from the Supabase/Postgres schema and WHY:
--   * uuid_generate_v4() -> ids generated in server JS (crypto.randomUUID)
--   * TIMESTAMPTZ / DATE / TIME        -> TEXT (ISO 8601 strings)
--   * JSONB (shared_fields, dynamic_fields) -> TEXT holding JSON
--   * BOOLEAN                          -> INTEGER (0/1)
--   * DECIMAL                          -> REAL
--   * Row Level Security policies      -> enforced in server.js (SQLite has no RLS)
--   * updated_at triggers              -> handled in server.js on UPDATE
--   * auth.users                       -> local `auth_users` table (preview only)
-- 004 (pg_cron / DocuSign) is server-side-only and not needed to preview the UI.
-- ============================================================

-- ─── AUTH USERS (preview stand-in for Supabase auth.users) ───
CREATE TABLE auth_users (
  id         TEXT PRIMARY KEY,
  email      TEXT UNIQUE NOT NULL,
  password   TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

-- ─── PROFILES ────────────────────────────────────────────────
CREATE TABLE profiles (
  id         TEXT PRIMARY KEY,
  role       TEXT NOT NULL CHECK (role IN ('admin','instructor','facility')),
  created_at TEXT DEFAULT (datetime('now'))
);

-- ─── SITE SETTINGS ───────────────────────────────────────────
CREATE TABLE site_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT,
  updated_at TEXT DEFAULT (datetime('now'))
);

-- ─── WELLNESS INSTRUCTORS ────────────────────────────────────
CREATE TABLE wellness_instructors (
  id                    TEXT PRIMARY KEY,
  user_id               TEXT,
  legal_name            TEXT NOT NULL,
  nickname              TEXT,
  business_name         TEXT,
  phone                 TEXT,
  email                 TEXT NOT NULL,
  address               TEXT,
  headshot_url          TEXT,
  bio                   TEXT,
  years_experience      INTEGER,
  teletraining          INTEGER DEFAULT 0,
  drive_minutes         INTEGER,
  space_requirements    TEXT,
  service_area_lat      REAL,
  service_area_lng      REAL,
  service_area_radius_km REAL,
  status                TEXT DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  admin_notes           TEXT,
  created_at            TEXT DEFAULT (datetime('now')),
  updated_at            TEXT DEFAULT (datetime('now'))
);

-- ─── INSTRUCTOR SERVICES ─────────────────────────────────────
CREATE TABLE instructor_services (
  id            TEXT PRIMARY KEY,
  instructor_id TEXT,
  service_name  TEXT NOT NULL
);

-- ─── INSTRUCTOR SOCIAL MEDIA ─────────────────────────────────
CREATE TABLE instructor_social_media (
  id            TEXT PRIMARY KEY,
  instructor_id TEXT,
  platform      TEXT NOT NULL,
  url           TEXT NOT NULL
);

-- ─── INSTRUCTOR CREDENTIALS ──────────────────────────────────
CREATE TABLE instructor_credentials (
  id              TEXT PRIMARY KEY,
  instructor_id   TEXT,
  credential_type TEXT NOT NULL CHECK (credential_type IN ('insurance','certification','license')),
  name            TEXT NOT NULL,
  issuing_body    TEXT,
  number          TEXT,
  expiry_date     TEXT,
  file_url        TEXT,   -- private storage path, admin-only (stripped for non-admin)
  status          TEXT DEFAULT 'active' CHECK (status IN ('active','expired','expiring_soon')),
  created_at      TEXT DEFAULT (datetime('now'))
);

-- ─── INSTRUCTOR AVAILABILITY ─────────────────────────────────
CREATE TABLE instructor_availability (
  id            TEXT PRIMARY KEY,
  instructor_id TEXT,
  day_of_week   TEXT NOT NULL CHECK (day_of_week IN ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')),
  start_time    TEXT NOT NULL,
  end_time      TEXT NOT NULL,
  updated_at    TEXT DEFAULT (datetime('now'))
);

-- ─── FACILITIES (incl. 003 fall-risk columns) ────────────────
CREATE TABLE facilities (
  id                   TEXT PRIMARY KEY,
  user_id              TEXT,
  facility_name        TEXT NOT NULL,
  director_name        TEXT NOT NULL,
  phone                TEXT,
  email                TEXT NOT NULL,
  address              TEXT,
  facility_type        TEXT NOT NULL CHECK (facility_type IN ('senior_daycare','medical_center')),
  services_desired     TEXT,
  preferred_schedule   TEXT,
  medical_considerations TEXT,
  budget_range         TEXT,   -- admin only
  status               TEXT DEFAULT 'active' CHECK (status IN ('active','inactive')),
  admin_notes          TEXT,
  last_fall_risk_date  TEXT,
  fall_risk_notes      TEXT,
  created_at           TEXT DEFAULT (datetime('now')),
  updated_at           TEXT DEFAULT (datetime('now'))
);

-- ─── MATCHES (incl. 003 rate columns) ────────────────────────
CREATE TABLE matches (
  id                      TEXT PRIMARY KEY,
  instructor_id           TEXT,
  facility_id             TEXT,
  shared_fields           TEXT DEFAULT '{}',   -- JSON
  created_by              TEXT,
  created_at              TEXT DEFAULT (datetime('now')),
  facility_monthly_rate   REAL,   -- admin only
  instructor_monthly_rate REAL    -- admin only
);

-- ─── CONTRACT TEMPLATES ──────────────────────────────────────
CREATE TABLE contract_templates (
  id            TEXT PRIMARY KEY,
  template_type TEXT NOT NULL CHECK (template_type IN ('facility','instructor')),
  content       TEXT NOT NULL,
  updated_at    TEXT DEFAULT (datetime('now')),
  updated_by    TEXT
);

-- ─── CONTRACTS ───────────────────────────────────────────────
CREATE TABLE contracts (
  id             TEXT PRIMARY KEY,
  contract_type  TEXT NOT NULL CHECK (contract_type IN ('facility','instructor')),
  party_id       TEXT NOT NULL,
  content        TEXT NOT NULL,
  dynamic_fields TEXT DEFAULT '{}',   -- JSON
  status         TEXT DEFAULT 'draft' CHECK (status IN ('draft','sent','signed')),
  file_url       TEXT,
  sent_at        TEXT,
  signed_at      TEXT,
  created_by     TEXT,
  created_at     TEXT DEFAULT (datetime('now'))
);

-- ─── NOTIFICATION LOG ────────────────────────────────────────
CREATE TABLE notification_log (
  id                TEXT PRIMARY KEY,
  notification_type TEXT NOT NULL,
  recipient_email   TEXT NOT NULL,
  subject           TEXT,
  status            TEXT DEFAULT 'sent',
  created_at        TEXT DEFAULT (datetime('now'))
);

-- ─── ADMIN COMMENTS ──────────────────────────────────────────
CREATE TABLE admin_comments (
  id          TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('instructor','facility','match','contract')),
  entity_id   TEXT NOT NULL,
  comment     TEXT NOT NULL,
  created_by  TEXT,
  created_at  TEXT DEFAULT (datetime('now'))
);

-- ─── SERVICE CATEGORIES (002) ────────────────────────────────
CREATE TABLE service_categories (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  sort_order INTEGER DEFAULT 0,
  active     INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

-- ─── INSTRUCTOR COMPLIANCE (003) ─────────────────────────────
CREATE TABLE instructor_compliance (
  id            TEXT PRIMARY KEY,
  instructor_id TEXT NOT NULL,
  item_key      TEXT NOT NULL,
  checked       INTEGER DEFAULT 0,
  checked_at    TEXT,
  checked_by    TEXT,
  notes         TEXT,
  UNIQUE (instructor_id, item_key)
);
