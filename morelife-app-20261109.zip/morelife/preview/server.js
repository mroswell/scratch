// preview/server.js
// ============================================================
// MORE LIFE — LOCAL PREVIEW SERVER (Node + better-sqlite3)
// Serves the real static app with ZERO edits to it, swapping the
// Supabase CDN <script> for the local shim on the fly, and exposing
// a tiny JSON API the shim talks to. Run: `node server.js`.
// Everything is in-memory; restart = clean demo data.
// ============================================================

const http = require('http');
const fs = require('fs');
const path = require('path');
const { buildDb, runQuery, runRpc, signIn, signUp } = require('./db');
const { USERS, DEMO_PASSWORD } = require('./seed');

const ROOT = path.join(__dirname, '..');            // the app repo root
const PORT = process.env.PORT || 3000;
const CDN_TAG = '<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>';
const SHIM_TAG = '<script src="/js/local-shim.js"></script>';

// Persistent demo DB: data now survives restarts (a file, not in-memory),
// so the client can tinker and come back to their changes. Override the
// location with PREVIEW_DB=/path/to.db. Pass --fresh (or --reset) to wipe
// it back to clean demo data — use that before handing the folder off.
const DB_PATH = process.env.PREVIEW_DB || path.join(__dirname, 'morelife-preview.db');
const FRESH = process.argv.includes('--fresh') || process.argv.includes('--reset');
if (FRESH) {
  for (const suffix of ['', '-wal', '-shm']) {
    const f = DB_PATH + suffix;
    if (fs.existsSync(f)) fs.unlinkSync(f);
  }
}
const isNewDb = !fs.existsSync(DB_PATH);
const db = buildDb(DB_PATH);

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}
function sendJson(res, status, obj) {
  send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8' });
}
function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { resolve({}); } });
  });
}
function ctxFrom(req) {
  return { role: req.headers['x-demo-role'] || 'anon', userId: req.headers['x-demo-user-id'] || null };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = decodeURIComponent(url.pathname);

  // ─── API ───────────────────────────────────────────────────
  if (pathname.startsWith('/api/')) {
    const body = await readBody(req);
    if (pathname === '/api/query')  return sendJson(res, 200, runQuery(db, body, ctxFrom(req)));
    if (pathname === '/api/rpc')    return sendJson(res, 200, runRpc(db, body.name, body.params));
    if (pathname === '/api/auth/signin') return sendJson(res, 200, signIn(db, body.email, body.password));
    if (pathname === '/api/auth/signup') return sendJson(res, 200, signUp(db, body.email, body.password));
    return sendJson(res, 404, { error: { message: 'Unknown API route' } });
  }

  // ─── stubbed private file links (storage is client-side) ──
  if (pathname.startsWith('/uploads/')) {
    return send(res, 200,
      `<!doctype html><meta charset=utf-8><body style="font-family:system-ui;padding:40px;max-width:640px;margin:auto">
       <h2>📄 Demo file placeholder</h2>
       <p>In the live app this is a signed, time-limited link to a private document
       (<code>${pathname.replace('/uploads/', '')}</code>). File storage is stubbed in the local preview —
       uploads you make in this session are kept in the browser and render inline.</p>
       <a href="javascript:history.back()">← Back</a></body>`,
      { 'Content-Type': 'text/html; charset=utf-8' });
  }

  // ─── landing page ──────────────────────────────────────────
  if (pathname === '/') return send(res, 200, landingPage(), { 'Content-Type': 'text/html; charset=utf-8' });

  // ─── static files (app, checklist, shim, markdown) ─────────
  let rel = pathname.replace(/^\/+/, '');
  let filePath = path.join(ROOT, rel);
  if (!filePath.startsWith(ROOT)) return send(res, 403, 'Forbidden'); // traversal guard
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    const idx = path.join(filePath, 'index.html');
    if (fs.existsSync(idx)) filePath = idx; else return send(res, 404, 'Not found');
  }

  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.html') {
    let html = fs.readFileSync(filePath, 'utf8').split(CDN_TAG).join(SHIM_TAG);
    return send(res, 200, html, { 'Content-Type': MIME['.html'] });
  }
  send(res, 200, fs.readFileSync(filePath), { 'Content-Type': MIME[ext] || 'application/octet-stream' });
});

server.listen(PORT, () => {
  console.log(`\n  More Life — local SQLite preview`);
  console.log(`  ▸ http://localhost:${PORT}\n`);
  console.log(`  Demo logins (password: ${DEMO_PASSWORD}):`);
  console.log(`    admin      ${USERS.admin.email}`);
  console.log(`    instructor ${USERS.instructor.email}`);
  console.log(`    facility   ${USERS.facility.email}`);
  console.log(`\n  Use the role switcher (top-right in the app) to hop between portals.`);
  console.log(`\n  Data file: ${path.relative(ROOT, DB_PATH)}  ${
    FRESH ? '(reset to clean demo data)' : isNewDb ? '(created with clean demo data)' : '(persisted — your changes are kept)'
  }`);
  console.log(`  Changes now survive restarts. To wipe back to clean demo data:  node server.js --fresh\n`);
});

// ─── landing page markup ─────────────────────────────────────
function landingPage() {
  return `<!doctype html><html lang=en><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>More Life — Local Preview</title>
<link rel="stylesheet" href="/css/main.css">
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f6f7f9;color:#1c1f26;margin:0}
  .wrap{max-width:860px;margin:0 auto;padding:48px 24px}
  .hero{background:#fff;border:1px solid #e6e8ec;border-radius:16px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,.05)}
  h1{margin:0 0 4px;font-size:1.8rem}.sub{color:#6b7280;margin:0 0 24px}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:8px}
  .card{display:block;border:1px solid #e6e8ec;border-radius:12px;padding:20px;text-decoration:none;color:inherit;background:#fff;transition:.15s}
  .card:hover{border-color:#111;transform:translateY(-2px)}
  .card h3{margin:0 0 6px}.card p{margin:0;color:#6b7280;font-size:.9rem}
  table{border-collapse:collapse;margin-top:12px;font-size:.9rem;width:100%}
  td,th{text-align:left;padding:6px 10px;border-bottom:1px solid #eef0f3}
  code{background:#f0f1f4;padding:2px 6px;border-radius:5px}
  .note{margin-top:24px;font-size:.85rem;color:#6b7280;line-height:1.5}
  @media(max-width:640px){.grid{grid-template-columns:1fr}}
</style></head>
<body><div class="wrap">
  <div class="hero">
    <h1>More Life — Local Preview</h1>
    <p class="sub">Running on local SQLite. No Supabase required. Restart the server for fresh demo data.</p>
    <div class="grid">
      <a class="card" href="/checklist/index.html"><h3>🗒️ Launch Checklist →</h3><p>Your setup progress tracker: preview locally, then stand up Supabase. Progress is saved and survives updates.</p></a>
      <a class="card" href="/index.html"><h3>🚀 Open the App →</h3><p>Sign in and click through the Admin, Instructor, and Facility portals with seeded demo data.</p></a>
      <a class="card" href="/preview/tutorial.html"><h3>🎓 Guided Tutorial →</h3><p>A hands-on walkthrough: make your first match and watch the privacy rules enforce themselves live.</p></a>
    </div>
    <h3 style="margin-top:28px">Demo logins</h3>
    <table>
      <tr><th>Role</th><th>Email</th><th>Password</th></tr>
      <tr><td>Admin</td><td><code>${USERS.admin.email}</code></td><td><code>${DEMO_PASSWORD}</code></td></tr>
      <tr><td>Instructor</td><td><code>${USERS.instructor.email}</code></td><td><code>${DEMO_PASSWORD}</code></td></tr>
      <tr><td>Facility</td><td><code>${USERS.facility.email}</code></td><td><code>${DEMO_PASSWORD}</code></td></tr>
    </table>
    <p class="note">Tip: once you're in the app, a <strong>role switcher</strong> appears top-right — jump between portals instantly without signing out. The privacy boundaries from the spec are enforced here too: a facility sees only the shared instructor profile, and neither side ever sees the other's rate.</p>
  </div>
</div></body></html>`;
}
