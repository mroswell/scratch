# More Life — Wellness Coordination Platform
## Setup & Deployment Guide

---

## Prerequisites

- A [Supabase](https://supabase.com) account (free)
- A [GitHub](https://github.com) account
- A [Resend](https://resend.com) account for transactional email (free tier available)
- [Supabase CLI](https://supabase.com/docs/guides/cli) installed locally (for Edge Functions)

---

## Step 1 — Supabase Project Setup

1. Create a new project at [supabase.com](https://supabase.com)
2. Go to **Settings → API** and copy:
   - `Project URL`
   - `anon / public key`
3. Go to the **SQL Editor** and run the full contents of:
   ```
   supabase/migrations/001_schema.sql
   ```
   This creates all tables, RLS policies, and default settings.

4. Go to **Storage** and create two buckets:
   - `headshots` — set to **Public**
   - `private-docs` — set to **Private** (no public URL access)

5. For `private-docs`, set the storage policy so only the service role can access files. In the Supabase Storage policies, add:
   ```sql
   -- Only authenticated admins can access private docs
   CREATE POLICY "Admin only - private docs"
   ON storage.objects FOR ALL
   USING (bucket_id = 'private-docs' AND get_user_role() = 'admin');
   ```

---

## Step 2 — Create Your Admin User

1. In Supabase go to **Authentication → Users → Invite User**
2. Enter your admin email address
3. After confirming the invite, go to the **SQL Editor** and run:
   ```sql
   INSERT INTO profiles (id, role)
   VALUES ('<your-user-uuid-from-auth-users-table>', 'admin');
   ```

---

## Step 3 — Deploy Email Edge Function

1. Install Supabase CLI and log in:
   ```bash
   npm install -g supabase
   supabase login
   ```
2. Link to your project:
   ```bash
   supabase link --project-ref YOUR_PROJECT_REF
   ```
3. Set your Resend API key as a secret:
   ```bash
   supabase secrets set RESEND_API_KEY=re_YOUR_KEY_HERE
   supabase secrets set FROM_EMAIL=noreply@yourdomain.com
   supabase secrets set FROM_NAME="More Life"
   ```
4. Deploy the function:
   ```bash
   supabase functions deploy send-email
   ```

---

## Step 4 — Configure the App

Open `js/config.js` and replace the placeholder values:

```javascript
const SUPABASE_URL = 'https://xxxxxxxxxxxx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGci...';
const SITE_URL = 'https://YOUR_GITHUB_USERNAME.github.io/morelife';
```

---

## Step 5 — Deploy to GitHub Pages

1. Create a new GitHub repository named `morelife`
2. Push all files to the `main` branch
3. Go to **Settings → Pages** and set source to `main` branch, root `/`
4. Your site will be live at: `https://YOUR_USERNAME.github.io/morelife/`

---

## Step 6 — First Login & Settings

1. Visit your site and sign in with your admin email
2. Go to **Admin → Settings** and fill in:
   - Business name, address, entity type
   - Admin phone number (appears in all instructor notices)
   - Admin email (receives all system notifications)
   - Contract signatory name and title
   - Review and update policy language as needed

---

## File Structure

```
morelife/
├── index.html                  ← Login / sign-in page
├── js/
│   ├── config.js               ← Supabase keys (fill in yours)
│   ├── app.js                  ← Shared utilities, auth, toasts
│   └── sidebar.js              ← Role-based navigation
├── css/
│   └── main.css                ← Full stylesheet
├── admin/
│   ├── dashboard.html          ← Admin home
│   ├── instructors.html        ← Instructor list
│   ├── instructor-detail.html  ← Instructor profile + approval
│   ├── facilities.html         ← Facility list
│   ├── facility-detail.html    ← Facility detail + matching
│   ├── matches.html            ← All matches (admin only)
│   ├── contracts.html          ← Contract manager
│   └── settings.html           ← Site settings panel
├── instructor/
│   ├── apply.html              ← Multi-step application form
│   └── portal.html             ← Instructor portal
├── facility/
│   ├── inquiry.html            ← Public inquiry form
│   └── portal.html             ← Facility portal
└── supabase/
    ├── migrations/
    │   └── 001_schema.sql      ← Full database schema + RLS
    └── functions/
        └── send-email/
            └── index.ts        ← Resend email Edge Function
```

---

## User Roles & Access

| Page | Admin | Instructor | Facility | Public |
|------|-------|------------|---------|--------|
| `/index.html` | ✓ | ✓ | ✓ | ✓ |
| `/facility/inquiry.html` | ✓ | ✓ | ✓ | ✓ |
| `/instructor/apply.html` | ✓ | ✓ | ✗ | ✓ |
| `/instructor/portal.html` | ✗ | ✓ | ✗ | ✗ |
| `/facility/portal.html` | ✗ | ✗ | ✓ | ✗ |
| `/admin/*` | ✓ | ✗ | ✗ | ✗ |

---

## Security Notes

- Insurance certificates and signed contracts are stored in the `private-docs` bucket — no public URLs are ever generated
- Supabase Row Level Security (RLS) enforces all role-based data restrictions at the database level
- The Supabase `anon` key is safe to expose in the browser because RLS policies control what each role can access
- Keep your `service_role` key secret — never put it in frontend code
- Private file downloads use temporary signed URLs (60 second expiry) generated only for admin users

---

## Next Steps (Future Enhancements)

- [ ] Integrate Dropbox Sign or DocuSign for electronic contract signatures
- [ ] Integrate Snipcart for facility payment processing
- [ ] Add automated credential expiry cron job (Supabase scheduled functions)
- [ ] Add Leaflet.js radius editing on the service area map
- [ ] Add instructor profile photo cropping

---

*More Life Platform — Confidential. For internal use only.*

---

## Cron Jobs (Daily Automation)

The `run-daily-jobs` Edge Function handles credential expiry warnings, facility payment reminders, and fall risk assessment reminders. It runs daily at 8:00 AM UTC via pg_cron.

### Step 1 — Enable extensions in Supabase Dashboard
Go to **Database → Extensions** and enable:
- `pg_cron`
- `pg_net`

### Step 2 — Deploy the function
```bash
supabase functions deploy run-daily-jobs
```

### Step 3 — Set the cron schedule
Run this in the **Supabase SQL Editor**, replacing the placeholders:

```sql
-- Set your project config
ALTER DATABASE postgres SET app.supabase_url = 'https://YOUR_PROJECT_REF.supabase.co';
ALTER DATABASE postgres SET app.service_role_key = 'YOUR_SERVICE_ROLE_KEY';

-- Schedule daily at 8:00 AM UTC
SELECT cron.schedule(
  'more-life-daily-jobs',
  '0 8 * * *',
  $job$
  SELECT net.http_post(
    url         := current_setting('app.supabase_url') || '/functions/v1/run-daily-jobs',
    headers     := jsonb_build_object(
      'Content-Type',  'application/json',
      'Authorization', 'Bearer ' || current_setting('app.service_role_key')
    ),
    body        := '{}'::jsonb
  ) AS request_id;
  $job$
);
```

### Step 4 — Set required secrets
```bash
supabase secrets set SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
# RESEND_API_KEY should already be set from initial setup
```

### Test manually
```sql
SELECT net.http_post(
  url     := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/run-daily-jobs',
  headers := '{"Content-Type":"application/json","Authorization":"Bearer YOUR_SERVICE_ROLE_KEY"}'::jsonb,
  body    := '{}'::jsonb
);
```

---

## DocuSign Integration

DocuSign is **optional** — the app works without it. When not configured, contracts are tracked manually (Mark Sent / Mark Signed buttons). When configured, a "Send via DocuSign" button sends the contract electronically and the signed status updates automatically via webhook.

### Step 1 — Deploy the function
```bash
supabase functions deploy docusign
```

### Step 2 — Set secrets
```bash
supabase secrets set DOCUSIGN_ACCOUNT_ID=your_account_id
supabase secrets set DOCUSIGN_ACCESS_TOKEN=your_access_token
supabase secrets set DOCUSIGN_BASE_URL=https://na4.docusign.net/restapi
supabase secrets set DOCUSIGN_WEBHOOK_SECRET=any_random_string
```

**Where to find these:** DocuSign Admin → Apps & Keys. Use `https://demo.docusign.net/restapi` for sandbox, `https://na4.docusign.net/restapi` for production (check your account region).

### Step 3 — Configure DocuSign Connect (webhook)
In your DocuSign account go to **Settings → Connect → Add Configuration**:
- URL to publish: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/docusign`
- Trigger events: Envelope Completed, Envelope Declined, Envelope Voided
- Include: Data → Envelope Fields

### Step 4 — Add /sig1/ and /date1/ anchor tags to contract templates
In the admin Contracts page, click **Edit Templates** and place these literal strings where signatures should appear:

```
/sig1/    ← DocuSign places the signature tab here
/date1/   ← DocuSign places the signed date here
```

Example at the bottom of your template:
```
IN WITNESS WHEREOF, the parties have executed this Agreement as of the date last signed below.

More Life: _________________________ Date: _____________

{{party_name}}: /sig1/ Date: /date1/
```

### Access Token Rotation
DocuSign access tokens expire. For production, implement JWT Grant authentication. For now, generate a new token in DocuSign Admin → Apps & Keys and update the secret:
```bash
supabase secrets set DOCUSIGN_ACCESS_TOKEN=new_token
```
