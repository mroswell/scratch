# More Life — Session Handoff / Where Things Stand

_Last updated: 2026-11-04_

A plain-English record of the work so nothing is lost between sessions.
Resume the Claude Code conversation from this folder with `claude --continue`.

## What we set out to do

Preview the already-built More Life app **before** investing in Supabase, using a
local SQLite backend, plus a single launch checklist to track progress. One app —
not two (see "Architecture" below).

## What was built (all on disk, in this repo)

1. **Launch checklist** — `checklist/` (`index.html`, `checklist.js`, `checklist.css`)
   - One list: a built-in "Phase 0 — Preview locally with SQLite" section, then the
     phases parsed live from `claude_code_task_list.md` (that markdown stays the
     single source of truth).
   - Progress saved in your browser's localStorage, keyed by a stable hash of each
     item's text, so checking things off **survives app updates** (new items appear
     unchecked; nothing already done gets wiped).

2. **Local SQLite preview** — `preview/` (throwaway dev tool, never shipped)
   - `server.js` — Node server on http://localhost:3000. Serves the real app and
     swaps the Supabase CDN `<script>` for `js/local-shim.js` on the fly.
   - `db.js` — query engine: translates Supabase-style calls to SQLite and enforces
     the spec's privacy rules in code (facility sees only the shared profile; neither
     side sees rates; credential files are admin-only).
   - `schema.sql` — SQLite translation of Supabase migrations 001+002+003.
   - `seed.js` — demo data (instructors, facilities, matches, contracts, settings).
   - `engine.test.js`, `checklist.test.js` — `npm test` (19 tests, all passing).

3. **Browser shim** — `js/local-shim.js` — drop-in replacement for the `sb` client
   (query builder, auth, storage, rpc) + the top-right role switcher. Only loaded by
   the preview server; never by the real GitHub Pages deployment.

4. **Bug fix** — `css/main.css` `.alert` was `display:flex`, which stacked inline
   text/links into columns (seen on the Contracts page DocuSign banner). Changed to
   `display:block`. Fixes it in both the preview and the real Supabase deployment.

## How to run the preview

```bash
cd preview
npm install          # one dependency: better-sqlite3
node server.js       # → http://localhost:3000  (Ctrl+C to stop)
node server.js --fresh   # wipe back to clean demo data (same as: npm run fresh)
```

Demo logins (password `demo1234`): `admin@morelife.test`, `grace@morelife.test`,
`sunrise@morelife.test`. Or use the top-right role switcher once in the app.

**Data persistence (changed 2026-11-04):** the preview DB is now a file on disk
(`preview/morelife-preview.db`), not in-memory — so changes you make in the app
**survive restarts**. This lets the client tinker and come back to their data.
- To reset to clean demo data: `node server.js --fresh` (deletes and reseeds the file).
- Handing the folder to someone else: run `--fresh` first (or delete the `.db` file)
  so they start clean; their own tinkering then persists on their machine.
- Still local/single-user with JS-level privacy — a demo tool, **not** production.
  Real multi-user/web use is the Supabase path (`README.md`).
- Tests still run on a throwaway in-memory DB (`buildDb()` with no path), so
  `npm test` is unaffected by the file.

## Architecture — it's ONE app, two backends

There is **not** a separate Postgres app and a separate SQLite app. There is one set
of app files (`index.html`, `admin/`, `instructor/`, `facility/`, `js/`, `css/`).

- **Production (Supabase / Postgres):** the app loads the Supabase library and
  `js/config.js` points at your real Supabase project. (Deployed to GitHub Pages.)
- **Local preview (SQLite):** the `preview/` server serves those **same files** but
  swaps in `js/local-shim.js`, which routes data to the local SQLite DB. No copy of
  the app, no duplication.

To remove the preview entirely: delete `preview/` and `js/local-shim.js`. The shipped
app and the Supabase schema are untouched.

## Open thread / next steps

- **Performance question (open):** the app and SQLite backend load fast (tens of ms).
  The only internet-dependent assets are **Leaflet + OpenStreetMap map tiles** on
  `instructor/apply.html` and `admin/instructor-detail.html`. If a page feels slow,
  it's likely one of those; the fix is to vendor Leaflet locally and lazy-load the map.
- **When ready for Supabase:** work the checklist's phases (from `claude_code_task_list.md`),
  starting with Phase 1 security/privacy items, against a real local Supabase.

## Reference

- Design/plan: `~/.claude/plans/we-built-this-spec-imperative-globe.md`
- Preview details: `preview/README.md`
- Original spec: `~/Documents/MoreLife_AppSpec_v3.docx`
- Feedback punch-list: `claude_code_task_list.md`
