// supabase/functions/run-daily-jobs/index.ts
// Scheduled daily via pg_cron at 8:00 AM UTC
// Deploy: supabase functions deploy run-daily-jobs
// Required secrets: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, RESEND_API_KEY, FROM_EMAIL, FROM_NAME

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL           = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_KEY   = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY         = Deno.env.get("RESEND_API_KEY")!;
const FROM_EMAIL             = Deno.env.get("FROM_EMAIL") || "noreply@morelife.app";
const FROM_NAME              = Deno.env.get("FROM_NAME") || "More Life";

// Admin Supabase client — bypasses RLS
const db = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

const corsHeaders = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ── EMAIL HELPER ─────────────────────────────────────────────
async function sendEmail(to: string, subject: string, html: string, entityId?: string, notificationType?: string) {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: `${FROM_NAME} <${FROM_EMAIL}>`, to: [to], subject, html }),
  });

  if (res.ok && entityId && notificationType) {
    await db.from("notification_log").insert({
      notification_type: notificationType,
      recipient_email:   to,
      subject,
      entity_id:         entityId,
      entity_type:       notificationType.split("_")[0],
      status:            "sent",
    });
  }

  return res.ok;
}

// ── DEDUP CHECK: has this notification been sent recently? ────
async function alreadySent(entityId: string, notificationType: string, withinDays = 20): Promise<boolean> {
  const since = new Date(Date.now() - withinDays * 24 * 60 * 60 * 1000).toISOString();
  const { data } = await db
    .from("notification_log")
    .select("id")
    .eq("entity_id", entityId)
    .eq("notification_type", notificationType)
    .gte("created_at", since)
    .limit(1);
  return (data?.length ?? 0) > 0;
}

// ── SETTINGS HELPER ───────────────────────────────────────────
async function getSetting(key: string): Promise<string> {
  const { data } = await db.from("site_settings").select("value").eq("key", key).single();
  return data?.value || "";
}

// ── FORMAT DATE ───────────────────────────────────────────────
function fmtDate(d: string | Date): string {
  return new Date(d).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

// ── EMAIL TEMPLATES ───────────────────────────────────────────
function credentialExpiringHtml(name: string, credName: string, credType: string, daysLeft: number, expiryDate: string, adminPhone: string, isAdmin = false): string {
  const header = isAdmin
    ? `<h2 style="color:#E67E22;">⚠ Credential Expiring — ${name}</h2>`
    : `<h2 style="color:#E67E22;">⚠ ${credType} Expiring Soon</h2>`;
  const body = isAdmin
    ? `<p>Instructor <strong>${name}</strong>'s <strong>${credName}</strong> expires in <strong>${daysLeft} days</strong> (${expiryDate}). They have been notified. Please follow up to ensure renewal.</p>`
    : `<p>Hi ${name},</p><p>Your <strong>${credName}</strong> expires in <strong>${daysLeft} days</strong> (${expiryDate}). Please contact us at <strong>${adminPhone}</strong> to arrange renewal.</p>`;
  return `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
    <div style="background:#1A5276;padding:24px;border-radius:8px 8px 0 0;"><h1 style="color:white;margin:0;font-size:24px;">More Life</h1></div>
    <div style="background:#f9f9f9;padding:32px;border-radius:0 0 8px 8px;border:1px solid #eee;">${header}${body}
      <p style="margin-top:32px;color:#666;font-size:14px;">— The More Life Team${isAdmin ? '' : '<br>' + adminPhone}</p>
    </div></div>`;
}

function paymentReminderHtml(facilityName: string, directorName: string, amount: number, dueDate: string, adminPhone: string, isAdmin = false): string {
  const header = isAdmin
    ? `<h2 style="color:#1A5276;">💳 Payment Due Soon — ${facilityName}</h2>`
    : `<h2 style="color:#1A5276;">💳 Upcoming Payment Reminder</h2>`;
  const body = isAdmin
    ? `<p>Facility <strong>${facilityName}</strong> has a payment of <strong>$${amount.toFixed(2)}</strong> due on <strong>${dueDate}</strong>. They have been notified.</p>`
    : `<p>Hi ${directorName},</p><p>Your upcoming More Life wellness services payment of <strong>$${amount.toFixed(2)}</strong> is due on <strong>${dueDate}</strong>. Payment will be collected via ACH from your account on file.</p><p>Questions? Call us at <strong>${adminPhone}</strong>.</p>`;
  return `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
    <div style="background:#1A5276;padding:24px;border-radius:8px 8px 0 0;"><h1 style="color:white;margin:0;font-size:24px;">More Life</h1></div>
    <div style="background:#f9f9f9;padding:32px;border-radius:0 0 8px 8px;border:1px solid #eee;">${header}${body}
      <p style="margin-top:32px;color:#666;font-size:14px;">— The More Life Team</p>
    </div></div>`;
}

function fallRiskOverdueHtml(facilityName: string, monthsOverdue: number, adminUrl: string): string {
  return `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
    <div style="background:#1A5276;padding:24px;border-radius:8px 8px 0 0;"><h1 style="color:white;margin:0;font-size:24px;">More Life Admin</h1></div>
    <div style="background:#f9f9f9;padding:32px;border-radius:0 0 8px 8px;border:1px solid #eee;">
      <h2 style="color:#E67E22;">⚠ Fall Risk Assessment Overdue</h2>
      <p>The bi-annual fall risk assessment for <strong>${facilityName}</strong> may be overdue (last logged approximately <strong>${monthsOverdue} months ago</strong>).</p>
      <p style="background:#FEF9E7;padding:12px;border-left:4px solid #F39C12;border-radius:4px;">
        Reminder: The assessment is performed and stored by the facility. Contact them to confirm it has been completed and update the date in your records.
      </p>
      <a href="${adminUrl}" style="display:inline-block;background:#1A5276;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;margin-top:16px;">View Facility</a>
      <p style="margin-top:32px;color:#666;font-size:14px;">— More Life Platform</p>
    </div></div>`;
}

// ════════════════════════════════════════════════════════════
// MAIN HANDLER
// ════════════════════════════════════════════════════════════
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const results: string[] = [];
  let totalEmails = 0;

  try {
    // Load settings once
    const [
      expiryFirst,
      expirySecond,
      paymentReminderDays,
      fallRiskMonths,
      adminEmail,
      adminPhone,
      businessName,
    ] = await Promise.all([
      getSetting("expiry_warning_days_first"),
      getSetting("expiry_warning_days_second"),
      getSetting("payment_reminder_days"),
      getSetting("fall_risk_reminder_months"),
      getSetting("admin_email"),
      getSetting("admin_phone"),
      getSetting("business_name"),
    ]);

    const firstWindow  = parseInt(expiryFirst)  || 30;
    const secondWindow = parseInt(expirySecond) || 7;
    const paymentDays  = parseInt(paymentReminderDays) || 5;
    const fallRiskMos  = parseInt(fallRiskMonths) || 6;
    const siteUrl      = SUPABASE_URL.replace(".supabase.co", "").replace("https://", "https://") + "";

    // ── 1. CREDENTIAL EXPIRY CHECKS ──────────────────────────
    const { data: credentials } = await db
      .from("instructor_credentials")
      .select(`
        id, name, credential_type, expiry_date, instructor_id,
        wellness_instructors (id, legal_name, nickname, email, status)
      `)
      .gt("expiry_date", new Date().toISOString().split("T")[0])
      .lte("expiry_date", new Date(Date.now() + firstWindow * 86400000).toISOString().split("T")[0])
      .eq("wellness_instructors.status", "approved");

    for (const cred of credentials || []) {
      const instructor = (cred as any).wellness_instructors;
      if (!instructor) continue;

      const expiryDate = new Date(cred.expiry_date);
      const today      = new Date();
      today.setHours(0, 0, 0, 0);
      const daysLeft   = Math.ceil((expiryDate.getTime() - today.getTime()) / 86400000);

      // Determine which window this falls into
      const inFirstWindow  = daysLeft <= firstWindow  && daysLeft > secondWindow;
      const inSecondWindow = daysLeft <= secondWindow;

      const windowLabel = inSecondWindow ? `expiry_${secondWindow}d` : `expiry_${firstWindow}d`;

      if (!inFirstWindow && !inSecondWindow) continue;

      // Check dedup — don't resend within 20 days for first window, 6 days for second
      const dedupDays = inSecondWindow ? 6 : 20;
      if (await alreadySent(cred.id, `instructor_${windowLabel}`, dedupDays)) continue;

      const name     = instructor.nickname || instructor.legal_name;
      const expStr   = fmtDate(cred.expiry_date);
      const adminUrl = `${siteUrl}/admin/instructor-detail.html?id=${instructor.id}`;

      // Email to instructor
      if (instructor.email) {
        const sent = await sendEmail(
          instructor.email,
          `Action Required — ${cred.name} expiring in ${daysLeft} days`,
          credentialExpiringHtml(name, cred.name, cred.credential_type, daysLeft, expStr, adminPhone),
          cred.id,
          `instructor_${windowLabel}`
        );
        if (sent) totalEmails++;
      }

      // Email to admin
      if (adminEmail) {
        const sent = await sendEmail(
          adminEmail,
          `⚠ Credential Expiring — ${instructor.legal_name} (${daysLeft} days)`,
          credentialExpiringHtml(instructor.legal_name, cred.name, cred.credential_type, daysLeft, expStr, adminPhone, true),
          cred.id,
          `admin_${windowLabel}`
        );
        if (sent) totalEmails++;
      }

      results.push(`Credential expiry (${daysLeft}d): ${instructor.legal_name} — ${cred.name}`);
    }

    // ── 2. FACILITY PAYMENT REMINDERS ────────────────────────
    const today = new Date();
    const targetDay = new Date(today.getTime() + paymentDays * 86400000);

    const { data: facilities } = await db
      .from("facilities")
      .select("id, facility_name, director_name, email, payment_due_day")
      .not("payment_due_day", "is", null)
      .not("email", "is", null);

    for (const facility of facilities || []) {
      if (!facility.payment_due_day) continue;

      // Check if the due day lands within the reminder window this month
      const dueDateThisMonth = new Date(today.getFullYear(), today.getMonth(), facility.payment_due_day);
      const dueDateNextMonth = new Date(today.getFullYear(), today.getMonth() + 1, facility.payment_due_day);

      // Use whichever is in the future
      const dueDate = dueDateThisMonth > today ? dueDateThisMonth : dueDateNextMonth;
      const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / 86400000);

      if (daysUntilDue !== paymentDays) continue; // Only send on the exact reminder day

      // Look up the negotiated monthly rate from a match
      const { data: matches } = await db
        .from("matches")
        .select("facility_monthly_rate")
        .eq("facility_id", facility.id)
        .not("facility_monthly_rate", "is", null);

      const totalAmount = (matches || []).reduce((s: number, m: any) => s + (parseFloat(m.facility_monthly_rate) || 0), 0);
      if (totalAmount === 0) continue; // No rate set — skip

      const dueDateStr = fmtDate(dueDate);
      const notifKey   = `payment_${dueDate.toISOString().split("T")[0]}`;

      if (await alreadySent(facility.id, notifKey, 3)) continue;

      // Email to facility
      const sent1 = await sendEmail(
        facility.email,
        `More Life — Payment of $${totalAmount.toFixed(2)} due ${dueDateStr}`,
        paymentReminderHtml(facility.facility_name, facility.director_name, totalAmount, dueDateStr, adminPhone),
        facility.id,
        notifKey
      );
      if (sent1) totalEmails++;

      // Email to admin
      if (adminEmail) {
        const sent2 = await sendEmail(
          adminEmail,
          `💳 Payment Due — ${facility.facility_name} ($${totalAmount.toFixed(2)} on ${dueDateStr})`,
          paymentReminderHtml(facility.facility_name, facility.director_name, totalAmount, dueDateStr, adminPhone, true),
          facility.id,
          `admin_${notifKey}`
        );
        if (sent2) totalEmails++;
      }

      results.push(`Payment reminder: ${facility.facility_name} — $${totalAmount.toFixed(2)} due ${dueDateStr}`);
    }

    // ── 3. FALL RISK ASSESSMENT REMINDERS ────────────────────
    const fallRiskCutoff = new Date(today.getTime() - fallRiskMos * 30 * 86400000).toISOString().split("T")[0];

    const { data: overdueAssessments } = await db
      .from("facilities")
      .select("id, facility_name")
      .not("last_fall_risk_date", "is", null)
      .lt("last_fall_risk_date", fallRiskCutoff);

    for (const facility of overdueAssessments || []) {
      const notifKey = `fallrisk_${new Date().toISOString().slice(0, 7)}`; // once per month max

      if (await alreadySent(facility.id, notifKey, 25)) continue;
      if (!adminEmail) continue;

      const { data: fac } = await db.from("facilities").select("last_fall_risk_date").eq("id", facility.id).single();
      const lastDate   = fac?.last_fall_risk_date ? new Date(fac.last_fall_risk_date) : new Date(0);
      const monthsAgo  = Math.floor((Date.now() - lastDate.getTime()) / (30 * 86400000));
      const adminUrl   = `${siteUrl}/admin/facility-detail.html?id=${facility.id}`;

      const sent = await sendEmail(
        adminEmail,
        `⚠ Fall Risk Assessment May Be Overdue — ${facility.facility_name}`,
        fallRiskOverdueHtml(facility.facility_name, monthsAgo, adminUrl),
        facility.id,
        notifKey
      );
      if (sent) totalEmails++;

      results.push(`Fall risk overdue reminder: ${facility.facility_name} (~${monthsAgo} months)`);
    }

    // ── 4. ALSO CHECK: facilities with NO fall risk date logged ─
    // Remind admin once if a facility has never had a date set and is older than X months
    const oldCutoff = new Date(today.getTime() - fallRiskMos * 30 * 86400000).toISOString();
    const { data: noAssessmentFacilities } = await db
      .from("facilities")
      .select("id, facility_name")
      .is("last_fall_risk_date", null)
      .lt("created_at", oldCutoff);

    for (const facility of noAssessmentFacilities || []) {
      if (!adminEmail) continue;
      const notifKey = `fallrisk_none_${new Date().toISOString().slice(0, 7)}`;
      if (await alreadySent(facility.id, notifKey, 25)) continue;

      const adminUrl = `${siteUrl}/admin/facility-detail.html?id=${facility.id}`;
      const sent = await sendEmail(
        adminEmail,
        `⚠ No Fall Risk Assessment on Record — ${facility.facility_name}`,
        fallRiskOverdueHtml(facility.facility_name, fallRiskMos, adminUrl),
        facility.id,
        notifKey
      );
      if (sent) totalEmails++;
      results.push(`Fall risk — no date on record: ${facility.facility_name}`);
    }

    const summary = {
      success: true,
      emails_sent: totalEmails,
      jobs_triggered: results.length,
      details: results,
      run_at: new Date().toISOString(),
    };

    console.log("Daily jobs complete:", JSON.stringify(summary));

    return new Response(JSON.stringify(summary), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("Daily jobs error:", err);
    return new Response(JSON.stringify({ success: false, error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
