// preview/engine.test.js — query translation + RLS-emulation tests
const { test } = require('node:test');
const assert = require('node:assert');
const { buildDb, runQuery, runRpc, signIn, signUp, parseSelect } = require('./db');

const admin = { role: 'admin', userId: 'demo-admin' };
const facility = { role: 'facility', userId: 'demo-sunrise' };
const instructor = { role: 'instructor', userId: 'demo-grace' };
const anon = { role: 'anon', userId: null };

function fresh() { return buildDb(); }

test('select-string parser handles nested embeds', () => {
  const p = parseSelect('id, shared_fields, wellness_instructors(id, legal_name, instructor_services(service_name))');
  assert.deepEqual(p.cols, ['id', 'shared_fields']);
  assert.equal(p.embeds.length, 1);
  assert.equal(p.embeds[0].name, 'wellness_instructors');
  assert.equal(p.embeds[0].select.embeds[0].name, 'instructor_services');
});

test('count/head query returns count without rows', () => {
  const db = fresh();
  const r = runQuery(db, { table: 'wellness_instructors', op: 'select', columns: '*', count: 'exact', head: true, filters: [{ col: 'status', op: 'eq', val: 'pending' }] }, admin);
  assert.equal(r.data, null);
  assert.equal(r.count, 1);
});

test('single() returns an object; maybeSingle() tolerates zero rows', () => {
  const db = fresh();
  const one = runQuery(db, { table: 'wellness_instructors', op: 'select', columns: '*', filters: [{ col: 'id', op: 'eq', val: 'i-grace' }], single: true }, admin);
  assert.equal(one.data.legal_name, 'Grace Nguyen');
  const none = runQuery(db, { table: 'contracts', op: 'select', columns: '*', filters: [{ col: 'id', op: 'eq', val: 'nope' }], maybeSingle: true }, admin);
  assert.equal(none.data, null);
  assert.equal(none.error, null);
});

test('rpc get_expiring_credentials returns the soon-to-expire cert', () => {
  const db = fresh();
  const r = runRpc(db, 'get_expiring_credentials', { days_ahead: 60 });
  assert.ok(Array.isArray(r.data));
  assert.ok(r.data.some(c => c.credential_name.includes('RYT-200')));
});

test('two-level embed: facility match -> instructor -> services/credentials', () => {
  const db = fresh();
  const r = runQuery(db, {
    table: 'matches', op: 'select',
    columns: 'id, shared_fields, created_at, wellness_instructors(id, legal_name, nickname, headshot_url, bio, teletraining, instructor_services(service_name), instructor_credentials(name, expiry_date, credential_type))',
    filters: [{ col: 'facility_id', op: 'eq', val: 'f-sunrise' }],
  }, facility);
  assert.equal(r.data.length, 1);
  const m = r.data[0];
  assert.equal(typeof m.shared_fields, 'object');           // JSON parsed
  assert.equal(m.wellness_instructors.legal_name, 'Grace Nguyen'); // to-one object
  assert.ok(Array.isArray(m.wellness_instructors.instructor_services)); // to-many array
  assert.ok(m.wellness_instructors.instructor_services.length >= 1);
});

test('RLS: facility cannot read instructors directly', () => {
  const db = fresh();
  const r = runQuery(db, { table: 'wellness_instructors', op: 'select', columns: '*' }, facility);
  assert.deepEqual(r.data, []);
});

test('RLS: facility never sees match rates; admin does', () => {
  const db = fresh();
  const fac = runQuery(db, { table: 'matches', op: 'select', columns: '*', filters: [{ col: 'facility_id', op: 'eq', val: 'f-sunrise' }] }, facility).data[0];
  assert.equal('facility_monthly_rate' in fac, false);
  assert.equal('instructor_monthly_rate' in fac, false);
  const adm = runQuery(db, { table: 'matches', op: 'select', columns: '*', filters: [{ col: 'id', op: 'eq', val: 'm-1' }] }, admin).data[0];
  assert.equal(adm.facility_monthly_rate, 400);
});

test('RLS: instructor sees own credential status but not file_url; admin sees file_url', () => {
  const db = fresh();
  const cred = runQuery(db, { table: 'instructor_credentials', op: 'select', columns: '*' }, instructor).data[0];
  assert.equal('file_url' in cred, false);
  const adm = runQuery(db, { table: 'instructor_credentials', op: 'select', columns: '*', filters: [{ col: 'id', op: 'eq', val: 'cr-1' }] }, admin).data[0];
  assert.ok(adm.file_url.length > 0);
});

test('RLS: instructor sees only own signed contract', () => {
  const db = fresh();
  const r = runQuery(db, { table: 'contracts', op: 'select', columns: 'id, status, contract_type, party_id' }, instructor);
  assert.equal(r.data.length, 1);
  assert.equal(r.data[0].party_id, 'i-grace');
  assert.equal(r.data[0].status, 'signed');
});

test('RLS: admin-only tables deny non-admin', () => {
  const db = fresh();
  assert.deepEqual(runQuery(db, { table: 'instructor_compliance', op: 'select', columns: '*' }, instructor).data, []);
  assert.deepEqual(runQuery(db, { table: 'admin_comments', op: 'select', columns: '*' }, facility).data, []);
});

test('public application: anonymous insert-with-returning yields a new row', () => {
  const db = fresh();
  const r = runQuery(db, {
    table: 'wellness_instructors', op: 'insert', returning: true, columns: '*', single: true,
    values: { legal_name: 'Test Person', email: 't@p.com', status: 'pending', teletraining: true },
  }, anon);
  assert.ok(r.data.id);
  assert.equal(r.data.legal_name, 'Test Person');
  assert.equal(r.data.teletraining, 1); // boolean coerced to int
});

test('write auth: non-admin cannot insert into matches or update site_settings', () => {
  const db = fresh();
  const m = runQuery(db, { table: 'matches', op: 'insert', values: { instructor_id: 'i-grace', facility_id: 'f-sunrise' } }, facility);
  assert.ok(m.error);
  const s = runQuery(db, { table: 'site_settings', op: 'upsert', values: { key: 'business_name', value: 'Hacked' } }, instructor);
  assert.ok(s.error);
  const stillOk = runQuery(db, { table: 'site_settings', op: 'select', columns: 'value', filters: [{ col: 'key', op: 'eq', val: 'business_name' }], single: true }, admin);
  assert.equal(stillOk.data.value, 'More Life');
});

test('admin upsert updates site_settings', () => {
  const db = fresh();
  runQuery(db, { table: 'site_settings', op: 'upsert', values: { key: 'admin_phone', value: '555', updated_at: '2026-01-01' } }, admin);
  const r = runQuery(db, { table: 'site_settings', op: 'select', columns: 'value', filters: [{ col: 'key', op: 'eq', val: 'admin_phone' }], single: true }, admin);
  assert.equal(r.data.value, '555');
});

test('or-filter ilike search works', () => {
  const db = fresh();
  const r = runQuery(db, { table: 'wellness_instructors', op: 'select', columns: 'id, legal_name', orFilter: 'legal_name.ilike.%grace%,email.ilike.%grace%' }, admin);
  assert.equal(r.data.length, 1);
  assert.equal(r.data[0].legal_name, 'Grace Nguyen');
});

test('auth: signin validates; bad password rejected; signup creates user', () => {
  const db = fresh();
  assert.equal(signIn(db, 'admin@morelife.test', 'demo1234').data.user.id, 'demo-admin');
  assert.ok(signIn(db, 'admin@morelife.test', 'nope').error);
  const su = signUp(db, 'new@person.test', 'pw');
  assert.ok(su.data.user.id);
  assert.ok(signUp(db, 'new@person.test', 'pw').error); // duplicate
});
