# More Life — Local SQLite Preview

A **throwaway** local version of the app so you can click through every portal
with realistic demo data — **no Supabase, no accounts, no setup beyond Node.**
Nothing here ships to GitHub Pages; it's a preview harness only.

## Run it

```bash
cd preview
npm install          # one native dependency: better-sqlite3
node server.js       # → http://localhost:3000
```

Open **http://localhost:3000** for the landing page, which links to:

- **Launch Checklist** — your setup progress tracker (`/checklist/`)
- **The App** — sign in and explore (`/index.html`)

### Demo logins (password `demo1234`)

| Role | Email |
|------|-------|
| Admin | `admin@morelife.test` |
| Instructor | `grace@morelife.test` |
| Facility | `sunrise@morelife.test` |

Once in the app, a **role switcher** appears top-right — hop between the Admin,
Instructor, and Facility portals instantly.

## How it works (and why it's safe)

- The server serves the **real, unmodified** app files and swaps the Supabase
  CDN `<script>` for `js/local-shim.js` on the fly. The shim implements the same
  `sb` client surface, backed by this server's in-memory SQLite DB
  (`schema.sql` + `seed.js`).
- The spec's **privacy boundaries are enforced in code** (`db.js`): a facility
  sees only the shared instructor profile, neither side sees the other's rate,
  and credential files are admin-only.
- Everything is **in-memory** — restart the server for fresh demo data.

To remove the preview entirely, delete this `preview/` folder and
`../js/local-shim.js`. The shipped app and the Supabase schema are untouched.

## Tests

```bash
npm test             # node --test: query translation, RLS emulation, checklist logic
```
