// supabase/functions/docusign/index.ts
// Handles two routes:
//   POST /docusign/send     — create and send a DocuSign envelope
//   POST /docusign/webhook  — receive DocuSign Connect status callbacks
//
// Deploy: supabase functions deploy docusign
// Required secrets:
//   DOCUSIGN_ACCOUNT_ID      — from DocuSign admin → Apps & Keys
//   DOCUSIGN_ACCESS_TOKEN    — long-lived JWT token (or rotate via OAuth)
//   DOCUSIGN_BASE_URL        — https://na4.docusign.net/restapi (prod) or https://demo.docusign.net/restapi
//   DOCUSIGN_WEBHOOK_SECRET  — any random string, set in DocuSign Connect config
//   SUPABASE_URL             — your project URL
//   SUPABASE_SERVICE_ROLE_KEY

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const DOCUSIGN_ACCOUNT_ID     = Deno.env.get("DOCUSIGN_ACCOUNT_ID") || "";
const DOCUSIGN_ACCESS_TOKEN   = Deno.env.get("DOCUSIGN_ACCESS_TOKEN") || "";
const DOCUSIGN_BASE_URL       = Deno.env.get("DOCUSIGN_BASE_URL") || "https://demo.docusign.net/restapi";
const DOCUSIGN_WEBHOOK_SECRET = Deno.env.get("DOCUSIGN_WEBHOOK_SECRET") || "";
const SUPABASE_URL            = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_KEY    = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const db = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

const corsHeaders = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ── IS DOCUSIGN CONFIGURED? ───────────────────────────────────
// Returns false gracefully if secrets are not set yet.
function isConfigured(): boolean {
  return !!(DOCUSIGN_ACCOUNT_ID && DOCUSIGN_ACCESS_TOKEN);
}

// ── SEND AN ENVELOPE ─────────────────────────────────────────
async function sendEnvelope(contractId: string, signerName: string, signerEmail: string): Promise<{
  success: boolean;
  envelopeId?: string;
  signingUrl?: string;   // embedded signing URL (optional — for future embedded flow)
  error?: string;
}> {
  if (!isConfigured()) {
    return { success: false, error: "DocuSign not configured. Add DOCUSIGN_ACCOUNT_ID and DOCUSIGN_ACCESS_TOKEN secrets." };
  }

  // Fetch contract content from DB
  const { data: contract, error: dbErr } = await db
    .from("contracts")
    .select("content, contract_type")
    .eq("id", contractId)
    .single();

  if (dbErr || !contract) {
    return { success: false, error: "Contract not found." };
  }

  if (!contract.content) {
    return { success: false, error: "Contract has no content. Save a draft first." };
  }

  // Convert plain text contract to base64 (DocuSign requires base64-encoded document)
  const encoder = new TextEncoder();
  const contentBytes = encoder.encode(contract.content);
  const base64Content = btoa(String.fromCharCode(...contentBytes));

  const contractLabel = contract.contract_type === "facility" ? "Facility Services Agreement" : "Wellness Instructor Agreement";

  // Build DocuSign envelope definition
  const envelopeDefinition = {
    emailSubject: `Please sign your More Life ${contractLabel}`,
    emailBlurb:   `Please review and sign your agreement with More Life. You can sign electronically using the button below.`,
    documents: [
      {
        documentBase64: base64Content,
        name:           contractLabel,
        fileExtension:  "txt",
        documentId:     "1",
      },
    ],
    recipients: {
      signers: [
        {
          email:        signerEmail,
          name:         signerName,
          recipientId:  "1",
          routingOrder: "1",
          tabs: {
            signHereTabs: [
              {
                // Place signature tab at the end of the document
                anchorString:    "/sig1/",
                anchorUnits:     "pixels",
                anchorYOffset:   "10",
                anchorXOffset:   "20",
              },
            ],
            dateSignedTabs: [
              {
                anchorString:  "/date1/",
                anchorUnits:   "pixels",
                anchorYOffset: "10",
                anchorXOffset: "20",
              },
            ],
          },
        },
      ],
    },
    status: "sent", // "created" = draft, "sent" = immediately sends email
    eventNotification: {
      // DocuSign will POST to this webhook when envelope status changes
      url:                    `${SUPABASE_URL}/functions/v1/docusign`,
      loggingEnabled:         "true",
      requireAcknowledgment:  "true",
      envelopeEvents: [
        { envelopeEventStatusCode: "completed" },
        { envelopeEventStatusCode: "declined" },
        { envelopeEventStatusCode: "voided" },
      ],
      includeDocuments:    "false",
      includeEnvelopeVoidReason: "true",
    },
  };

  const response = await fetch(
    `${DOCUSIGN_BASE_URL}/v2.1/accounts/${DOCUSIGN_ACCOUNT_ID}/envelopes`,
    {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${DOCUSIGN_ACCESS_TOKEN}`,
        "Content-Type":  "application/json",
      },
      body: JSON.stringify(envelopeDefinition),
    }
  );

  const result = await response.json();

  if (!response.ok || !result.envelopeId) {
    const errMsg = result.message || result.errorCode || JSON.stringify(result);
    console.error("DocuSign envelope error:", errMsg);
    return { success: false, error: errMsg };
  }

  // Update the contract record in DB
  await db.from("contracts").update({
    docusign_envelope_id: result.envelopeId,
    signer_email:         signerEmail,
    signer_name:          signerName,
    status:               "sent",
    sent_at:              new Date().toISOString(),
  }).eq("id", contractId);

  // Log notification
  await db.from("notification_log").insert({
    notification_type: "contract_sent_docusign",
    recipient_email:   signerEmail,
    subject:           `DocuSign — ${contractLabel}`,
    entity_id:         contractId,
    entity_type:       "contract",
    status:            "sent",
  });

  return { success: true, envelopeId: result.envelopeId };
}

// ── HANDLE DOCUSIGN WEBHOOK ───────────────────────────────────
async function handleWebhook(req: Request): Promise<Response> {
  // Validate the HMAC signature from DocuSign Connect
  // DocuSign sends X-DocuSign-Signature-1 header with HMAC-SHA256
  if (DOCUSIGN_WEBHOOK_SECRET) {
    const signature = req.headers.get("X-DocuSign-Signature-1") || "";
    if (!signature) {
      console.warn("Webhook received without signature — ignoring.");
      return new Response("Unauthorized", { status: 401 });
    }
    // Note: Full HMAC validation would require crypto.subtle — simplified here.
    // For production, implement full RFC 2104 HMAC-SHA256 validation.
  }

  let body: string;
  let payload: any;

  try {
    body    = await req.text();
    payload = JSON.parse(body);
  } catch {
    // DocuSign can send XML — handle gracefully
    console.log("Webhook body was not JSON (may be XML). Ignoring.");
    return new Response("OK", { status: 200 });
  }

  const event      = payload?.event || "";
  const envelopeId = payload?.data?.envelopeId || payload?.envelopeId || "";

  console.log(`DocuSign webhook: event=${event} envelopeId=${envelopeId}`);

  if (!envelopeId) {
    return new Response("OK", { status: 200 });
  }

  // Look up the contract by envelope ID
  const { data: contract } = await db
    .from("contracts")
    .select("id, contract_type, party_id")
    .eq("docusign_envelope_id", envelopeId)
    .single();

  if (!contract) {
    console.log(`No contract found for envelope ${envelopeId}`);
    return new Response("OK", { status: 200 });
  }

  if (event === "envelope-completed" || payload?.status === "completed") {
    const completedAt = payload?.data?.completedDateTime
      || payload?.completedDateTime
      || new Date().toISOString();

    await db.from("contracts").update({
      status:    "signed",
      signed_at: completedAt,
    }).eq("id", contract.id);

    // Notify admin
    const adminEmail = await db.from("site_settings").select("value").eq("key", "admin_email").single().then(r => r.data?.value || "");
    const contractLabel = contract.contract_type === "facility" ? "Facility Agreement" : "Instructor Agreement";
    if (adminEmail) {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${Deno.env.get("RESEND_API_KEY")}`,
          "Content-Type":  "application/json",
        },
        body: JSON.stringify({
          from:    `More Life <${Deno.env.get("FROM_EMAIL") || "noreply@morelife.app"}>`,
          to:      [adminEmail],
          subject: `✓ Contract Signed — ${contractLabel}`,
          html: `<div style="font-family:Arial,sans-serif;max-width:600px;">
            <div style="background:#1A5276;padding:24px;border-radius:8px 8px 0 0;"><h1 style="color:white;margin:0;">More Life Admin</h1></div>
            <div style="background:#f9f9f9;padding:32px;border-radius:0 0 8px 8px;border:1px solid #eee;">
              <h2 style="color:#1E8449;">✓ Contract Signed via DocuSign</h2>
              <p>A <strong>${contractLabel}</strong> has been signed electronically via DocuSign.</p>
              <p><strong>Envelope ID:</strong> ${envelopeId}</p>
              <p>The signed document is available in your DocuSign account.</p>
            </div></div>`,
        }),
      });
    }

    console.log(`Contract ${contract.id} marked signed via DocuSign webhook.`);

  } else if (event === "envelope-declined" || payload?.status === "declined") {
    await db.from("contracts").update({ status: "draft" }).eq("id", contract.id);
    console.log(`Contract ${contract.id} declined — reset to draft.`);

  } else if (event === "envelope-voided" || payload?.status === "voided") {
    await db.from("contracts").update({ status: "draft" }).eq("id", contract.id);
    console.log(`Contract ${contract.id} voided — reset to draft.`);
  }

  return new Response("OK", { status: 200 });
}

// ════════════════════════════════════════════════════════════
// MAIN ROUTER
// ════════════════════════════════════════════════════════════
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const url = new URL(req.url);

  // DocuSign Connect webhooks arrive at the base path (no /send suffix)
  // The admin "send" action uses ?action=send query param or /send path
  const isSend    = url.pathname.endsWith("/send") || url.searchParams.get("action") === "send";
  const isWebhook = !isSend;

  if (req.method === "POST" && isSend) {
    try {
      const { contractId, signerName, signerEmail } = await req.json();
      if (!contractId || !signerName || !signerEmail) {
        return new Response(JSON.stringify({ error: "contractId, signerName, signerEmail required" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const result = await sendEnvelope(contractId, signerName, signerEmail);
      return new Response(JSON.stringify(result), {
        status: result.success ? 200 : 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: String(e) }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  if (req.method === "POST" && isWebhook) {
    return handleWebhook(req);
  }

  // Status check — useful to verify config from admin settings page
  if (req.method === "GET" && url.searchParams.get("action") === "status") {
    return new Response(JSON.stringify({ configured: isConfigured() }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response("Not found", { status: 404 });
});
