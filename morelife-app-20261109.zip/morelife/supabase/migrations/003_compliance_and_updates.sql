-- ============================================================
-- MORE LIFE — MIGRATION 003
-- Run in Supabase SQL editor AFTER 001 and 002
-- ============================================================

-- ── INSTRUCTOR COMPLIANCE CHECKLIST ──────────────────────────
-- Tracks per-instructor Admin onboarding checkboxes
CREATE TABLE instructor_compliance (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  instructor_id UUID REFERENCES wellness_instructors(id) ON DELETE CASCADE NOT NULL,
  item_key      TEXT NOT NULL,   -- e.g. 'insurance_on_file'
  checked       BOOLEAN DEFAULT FALSE,
  checked_at    TIMESTAMPTZ,
  checked_by    UUID REFERENCES auth.users(id),
  notes         TEXT,
  UNIQUE (instructor_id, item_key)
);

ALTER TABLE instructor_compliance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admin only - compliance checklist"
  ON instructor_compliance FOR ALL
  USING (get_user_role() = 'admin');

-- ── FACILITY — FALL RISK FIELDS ───────────────────────────────
ALTER TABLE facilities
  ADD COLUMN IF NOT EXISTS last_fall_risk_date DATE,
  ADD COLUMN IF NOT EXISTS fall_risk_notes     TEXT;

-- ── MATCHES — RATE & MARGIN FIELDS ───────────────────────────
-- Admin records the negotiated rates per match so margin can be tracked
ALTER TABLE matches
  ADD COLUMN IF NOT EXISTS facility_monthly_rate  DECIMAL(10,2),
  ADD COLUMN IF NOT EXISTS instructor_monthly_rate DECIMAL(10,2);

-- ── UPDATE SITE SETTINGS DEFAULTS ────────────────────────────
-- Change expiry warnings to 30 days and 7 days (1 week)
UPDATE site_settings SET value = '30' WHERE key = 'expiry_warning_days_first';
UPDATE site_settings SET value = '7'  WHERE key = 'expiry_warning_days_second';

-- Add new settings (only if they don't already exist)
INSERT INTO site_settings (key, value) VALUES
  ('session_reminder_hours',     '24'),
  ('payment_reminder_days',      '5'),
  ('fall_risk_reminder_months',  '6'),
  ('governing_state',            'Florida'),
  ('default_notice_days',        '30'),
  ('docusign_api_key',           ''),
  ('payment_processor',          ''),
  ('payment_processor_key',      ''),
  ('instructor_pay_cycle',       'biweekly')
ON CONFLICT (key) DO NOTHING;

-- ── SEED COMPLIANCE ITEMS FOR EXISTING APPROVED INSTRUCTORS ──
-- Creates unchecked rows for every approved instructor
-- so the checklist is immediately visible in the admin view
INSERT INTO instructor_compliance (instructor_id, item_key, checked)
SELECT id, item_key, FALSE
FROM wellness_instructors
CROSS JOIN (VALUES
  ('insurance_on_file'),
  ('certificate_holder_confirmed'),
  ('certifications_verified'),
  ('social_media_reviewed'),
  ('contract_signed'),
  ('ach_collected')
) AS items(item_key)
WHERE status = 'approved'
ON CONFLICT (instructor_id, item_key) DO NOTHING;
