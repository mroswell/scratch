// checklist/checklist.js
// ============================================================
// MORE LIFE — LAUNCH CHECKLIST
// Renders ONE launch/setup checklist: a built-in "preview locally"
// phase followed by the phases parsed from claude_code_task_list.md
// (the markdown stays the single source of truth). Checked state is
// persisted in localStorage keyed by a STABLE hash of each item's
// text, so progress survives app updates: new items appear unchecked,
// removed items are ignored, and existing checks are never wiped.
// ============================================================

const STORAGE_KEY = 'morelife_checklist_v1';
const MD_PATHS = ['../claude_code_task_list.md', '/claude_code_task_list.md', 'claude_code_task_list.md'];

// Built-in first phase (owned by the app, not the markdown): preview locally.
const PREVIEW_SECTION = {
  title: 'Phase 0 — Preview locally with SQLite (no Supabase)',
  preview: true,
  items: [
    { type: 'note', text: 'Experience the whole app on local SQLite before investing in Supabase. Nothing here touches the live backend.' },
    { type: 'task', text: 'Install preview dependencies: `cd preview && npm install`' },
    { type: 'task', text: 'Start the preview (from the `preview` folder): `node server.js`, then open http://localhost:3000' },
    { type: 'task', text: 'Sign in as Admin and review the dashboard, instructor list, facilities, matches, and contracts' },
    { type: 'task', text: 'Use the role switcher (top-right) to open the Instructor portal — check the profile, availability, and credential status' },
    { type: 'task', text: 'Switch to the Facility portal and confirm you see ONLY the shared instructor profile — no rates, no private contact details' },
    { type: 'task', text: 'Submit a test instructor application and watch it land in the Admin approval queue' },
    { type: 'task', text: 'Happy with what you see? Continue to the Supabase setup phases below.' },
  ],
};

// ─── pure helpers (also exported for tests) ──────────────────
function djb2(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}
function normalize(text) { return String(text).replace(/\s+/g, ' ').trim().toLowerCase(); }
function stableId(sectionTitle, text) { return djb2(normalize(sectionTitle) + '|' + normalize(text)); }

function parseMarkdown(md) {
  const sections = [];
  let cur = null, sub = null;
  for (const raw of md.split(/\r?\n/)) {
    const t = raw.trim();
    if (!t) continue;
    if (/^-{3,}$/.test(t)) continue;            // horizontal rule
    let m;
    if ((m = t.match(/^(#{1,6})\s+(.*)/))) {
      const level = m[1].length;
      if (level === 1) { cur = null; continue; } // skip the document H1 title
      cur = { title: m[2].replace(/\*/g, '').trim(), items: [] };
      sections.push(cur);
      sub = null;
      continue;
    }
    if (!cur) continue;                          // ignore intro before first heading
    if ((m = t.match(/^[-*]\s*\[( |x|X)\]\s*(.*)/))) { cur.items.push({ type: 'task', text: m[2].trim() }); continue; }
    if ((m = t.match(/^\*\*(.+?)\*\*:?$/))) { sub = m[1].trim(); cur.items.push({ type: 'subhead', text: sub }); continue; }
    if ((m = t.match(/^[-*]\s+(.*)/))) { cur.items.push({ type: 'note', text: m[1].trim() }); continue; }
    cur.items.push({ type: 'note', text: t });
  }
  return sections;
}

// Merge saved state onto sections; returns { total, done } over task items.
function applyState(sections, saved) {
  let total = 0, done = 0;
  for (const s of sections) {
    for (const it of s.items) {
      if (it.type !== 'task') continue;
      it.id = stableId(s.title, it.text);
      it.done = !!(saved[it.id] && saved[it.id].done);
      total++;
      if (it.done) done++;
    }
  }
  return { total, done };
}

// ─── browser rendering + persistence ─────────────────────────
function loadSaved() { try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch { return {}; } }
function saveState(state) { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }

// minimal inline markdown: `code` and **bold**
function inlineMd(text, el) {
  el.textContent = '';
  const re = /(`[^`]+`|\*\*[^*]+\*\*)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) el.appendChild(document.createTextNode(text.slice(last, m.index)));
    const tok = m[0];
    if (tok.startsWith('`')) { const c = document.createElement('code'); c.textContent = tok.slice(1, -1); el.appendChild(c); }
    else { const b = document.createElement('strong'); b.textContent = tok.slice(2, -2); el.appendChild(b); }
    last = re.lastIndex;
  }
  if (last < text.length) el.appendChild(document.createTextNode(text.slice(last)));
}

function render(sections) {
  const saved = loadSaved();
  const totals = applyState(sections, saved);
  const root = document.getElementById('checklist');
  root.innerHTML = '';

  const updateOverall = () => {
    let total = 0, done = 0;
    document.querySelectorAll('.task input').forEach(cb => { total++; if (cb.checked) done++; });
    document.getElementById('overall-label').textContent = `${done} / ${total}`;
    document.getElementById('overall-fill').style.width = total ? (done / total * 100) + '%' : '0%';
  };

  sections.forEach(section => {
    const tasks = section.items.filter(i => i.type === 'task');
    const sEl = document.createElement('section');
    sEl.className = 'section' + (section.preview ? ' preview' : '');

    const head = document.createElement('div');
    head.className = 'section-head';
    head.innerHTML = `<span class="chevron">▼</span><h2></h2><div class="mini-bar"><div class="mini-fill"></div></div><span class="count"></span>`;
    head.querySelector('h2').textContent = section.title;
    sEl.appendChild(head);

    const body = document.createElement('div');
    body.className = 'section-body';

    const refreshSection = () => {
      const doneCount = tasks.filter(t => t.done).length;
      head.querySelector('.count').textContent = tasks.length ? `${doneCount}/${tasks.length}` : '';
      head.querySelector('.mini-fill').style.width = tasks.length ? (doneCount / tasks.length * 100) + '%' : '0%';
      sEl.classList.toggle('complete', tasks.length > 0 && doneCount === tasks.length);
    };

    section.items.forEach(item => {
      if (item.type === 'subhead') {
        const d = document.createElement('div'); d.className = 'subhead'; d.textContent = item.text; body.appendChild(d);
      } else if (item.type === 'note') {
        const d = document.createElement('div'); d.className = 'note'; inlineMd(item.text, d); body.appendChild(d);
      } else {
        const row = document.createElement('label');
        row.className = 'task' + (item.done ? ' done' : '');
        const cb = document.createElement('input');
        cb.type = 'checkbox'; cb.checked = item.done;
        const txt = document.createElement('span'); txt.className = 'txt'; inlineMd(item.text, txt);
        row.appendChild(cb); row.appendChild(txt);
        cb.addEventListener('change', () => {
          item.done = cb.checked;
          row.classList.toggle('done', cb.checked);
          const st = loadSaved();
          st[item.id] = { done: cb.checked, ts: Date.now() };
          saveState(st);
          refreshSection(); updateOverall();
          flashSaved();
        });
        body.appendChild(row);
      }
    });

    sEl.appendChild(body);
    head.addEventListener('click', e => { if (e.target.tagName !== 'INPUT') sEl.classList.toggle('collapsed'); });
    root.appendChild(sEl);
    refreshSection();
  });

  updateOverall();
}

let savedTimer = null;
function flashSaved() {
  const el = document.getElementById('saved-note');
  el.textContent = 'Progress saved ✓';
  clearTimeout(savedTimer);
  savedTimer = setTimeout(() => { el.textContent = ''; }, 1500);
}

async function fetchMarkdown() {
  for (const p of MD_PATHS) {
    try {
      const r = await fetch(p);
      if (r.ok) return await r.text();
    } catch (_) { /* try next */ }
  }
  return null;
}

async function init() {
  const md = await fetchMarkdown();
  const sections = [PREVIEW_SECTION];
  if (md) {
    sections.push(...parseMarkdown(md));
  } else {
    const banner = document.createElement('div');
    banner.className = 'banner';
    banner.innerHTML = `Couldn't load <code>claude_code_task_list.md</code>. Open this page through the preview server (<code>node preview/server.js</code> → http://localhost:3000/checklist/) so the feedback phases load. The preview phase below still works.`;
    document.getElementById('checklist').before(banner);
  }
  render(sections);

  document.getElementById('reset-btn').addEventListener('click', () => {
    if (confirm('Clear all checked items on this device?')) { localStorage.removeItem(STORAGE_KEY); render(sections); }
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { djb2, stableId, normalize, parseMarkdown, applyState };
} else {
  init();
}
