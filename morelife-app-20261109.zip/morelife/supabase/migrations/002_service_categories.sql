-- ============================================================
-- MORE LIFE — MIGRATION 002
-- Service Categories (Admin-managed)
-- Run this in your Supabase SQL editor AFTER 001_schema.sql
-- ============================================================

CREATE TABLE service_categories (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  sort_order INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE service_categories ENABLE ROW LEVEL SECURITY;

-- Anyone authenticated can read active categories (needed for forms)
CREATE POLICY "Authenticated users can read active categories"
  ON service_categories FOR SELECT
  USING (auth.role() = 'authenticated' AND active = TRUE);

-- Public (unauthenticated) can also read active categories (needed for public application/inquiry forms)
CREATE POLICY "Public can read active categories"
  ON service_categories FOR SELECT
  USING (active = TRUE);

-- Only admin can insert/update/delete
CREATE POLICY "Admin can manage categories"
  ON service_categories FOR ALL
  USING (get_user_role() = 'admin');

-- Auto-update timestamp
CREATE TRIGGER update_service_categories_updated_at
  BEFORE UPDATE ON service_categories
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── SEED DEFAULT CATEGORIES ───────────────────────────────────
INSERT INTO service_categories (name, sort_order, active) VALUES
  ('Chair Yoga',              1,  TRUE),
  ('Balance Training',        2,  TRUE),
  ('Strength Training',       3,  TRUE),
  ('Coordination',            4,  TRUE),
  ('Pilates',                 5,  TRUE),
  ('Fitness',                 6,  TRUE),
  ('Tai Chi',                 7,  TRUE),
  ('Stretching & Flexibility',8,  TRUE),
  ('Breathing & Relaxation',  9,  TRUE),
  ('Neurosize',               10, TRUE),
  ('Other',                   11, TRUE);

-- ── MIGRATE EXISTING INSTRUCTOR SERVICES ──────────────────────
-- If you already have instructor_services rows with hardcoded names,
-- they still work — instructor_services stores the service name as text.
-- No migration needed for existing data.
